export function getRandomPlayer(): number {
  return Math.floor(Math.random() * 1000) + 1;
}

export function isValidPlayerId(id: string | number): boolean {
  const playerId = typeof id === 'string' ? parseInt(id) : id;
  return !isNaN(playerId) && playerId >= 1 && playerId <= 1000;
}

export function getPlayerStats() {
  const visitedPlayers = JSON.parse(localStorage.getItem('visitedPlayers') || '[]');
  return {
    totalPlayers: 1000,
    visitedCount: visitedPlayers.length,
    visitedPlayers: new Set(visitedPlayers)
  };
}

export function markPlayerVisited(playerId: number) {
  const visitedPlayers = JSON.parse(localStorage.getItem('visitedPlayers') || '[]');
  if (!visitedPlayers.includes(playerId)) {
    visitedPlayers.push(playerId);
    localStorage.setItem('visitedPlayers', JSON.stringify(visitedPlayers));
  }
}

export function getYouTubeEmbedUrl(videoId: string = 'C7Q_Zl8hQkY', autoplay: boolean = true): string {
  const autoplayParam = autoplay ? '&autoplay=1' : '';
  return `https://www.youtube.com/embed/${videoId}?enablejsapi=1&rel=0&modestbranding=1${autoplayParam}&mute=1&loop=1&playlist=${videoId}`;
}

export const generateVirtualIP = (): string => {
  // Generate unique virtual IP for each client (192.168.x.x range)
  const subnet = Math.floor(Math.random() * 255) + 1;
  const host = Math.floor(Math.random() * 254) + 1;
  return `192.168.${subnet}.${host}`;
};

export const generateMacAddress = (): string => {
  // Generate a unique MAC address for each player
  const hexChars = '0123456789ABCDEF';
  let mac = '';
  for (let i = 0; i < 12; i++) {
    if (i > 0 && i % 2 === 0) mac += ':';
    mac += hexChars[Math.floor(Math.random() * 16)];
  }
  return mac;
};

export const formatNetworkInfo = (ip: string, userAgent: string): string => {
  const browser = userAgent.includes('Chrome') ? 'Chrome' : 
                 userAgent.includes('Firefox') ? 'Firefox' : 
                 userAgent.includes('Safari') ? 'Safari' : 'Unknown';
  return `${ip} (${browser})`;
};

export const generateUniquePlayerId = (): number => {
  return Math.floor(Math.random() * 1000) + 1;
};

export function generateVirtualPort(playerId: number): number {
  // Generate a virtual port based on player ID (8000-8999 range)
  return 8000 + (playerId % 1000);
}

export function getVirtualNetworkInfo(playerId: number) {
  // Generate unique network segments for each player
  const networkSegments = [
    "10.0", "172.16", "192.168", "10.1", "172.17", "10.2"
  ];

  const segmentIndex = Math.floor((playerId - 1) / 254) % networkSegments.length;
  const baseIp = networkSegments[segmentIndex];
  const subnet = Math.floor((playerId - 1) / 254) + 1;
  const host = ((playerId - 1) % 254) + 1;

  // Create more diverse IP ranges
  const finalSubnet = subnet % 255;
  const finalHost = host;

  return {
    ip: `${baseIp}.${finalSubnet}.${finalHost}`,
    port: 8000 + playerId,
    mac: generateMacAddress(),
    hostname: `player-${playerId}.local`,
    gateway: `${baseIp}.${finalSubnet}.1`,
    dns: [`8.8.8.8`, `1.1.1.1`],
    status: "connected",
    bandwidth: `${Math.floor(Math.random() * 900) + 100} Mbps`
  };
}