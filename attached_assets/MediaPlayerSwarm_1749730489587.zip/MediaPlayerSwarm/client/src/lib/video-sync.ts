// Video synchronization system using WebSocket and localStorage fallback
export interface VideoSyncState {
  isPlaying: boolean;
  currentTime: number;
  lastUpdate: number;
  playerId?: number;
}

const SYNC_KEY = 'video_sync_state';
const SYNC_EVENT = 'video_sync_update';

export class VideoSyncManager {
  private listeners: ((state: VideoSyncState) => void)[] = [];
  private syncInterval: NodeJS.Timeout | null = null;
  private ws: WebSocket | null = null;
  private reconnectInterval: NodeJS.Timeout | null = null;
  private isConnected = false;

  constructor() {
    // Try to initialize WebSocket connection (fallback to localStorage if fails)
    try {
      this.initWebSocket();
    } catch (error) {
      console.log('WebSocket not available, using localStorage sync');
    }

    // Listen for storage changes from other tabs/players
    window.addEventListener('storage', this.handleStorageChange.bind(this));

    // Listen for custom sync events
    window.addEventListener(SYNC_EVENT as any, this.handleSyncEvent.bind(this));

    // Start periodic sync check
    this.startSyncInterval();

    // Initialize with auto-play state
    this.initializeAutoPlay();
  }

  private initWebSocket() {
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/video-sync`;

      console.log(`Connecting to video sync server: ${wsUrl}`);
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        console.log('Video sync WebSocket connected');
        this.isConnected = true;
        if (this.reconnectInterval) {
          clearInterval(this.reconnectInterval);
          this.reconnectInterval = null;
        }

        // Start heartbeat
        this.startHeartbeat();
      };

      this.ws.onmessage = (event) => {
        try {
          const state: VideoSyncState = JSON.parse(event.data);
          this.notifyListeners(state);
          // Also update localStorage for fallback
          localStorage.setItem(SYNC_KEY, JSON.stringify(state));
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };

      this.ws.onclose = () => {
        console.log('Video sync WebSocket disconnected');
        this.isConnected = false;
        this.ws = null;
        this.scheduleReconnect();
      };

      this.ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        this.isConnected = false;
      };
    } catch (error) {
      console.error('Failed to initialize WebSocket:', error);
      this.scheduleReconnect();
    }
  }

  private startHeartbeat() {
    // Send heartbeat every 30 seconds
    setInterval(() => {
      if (this.isConnected && this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({
          type: 'heartbeat',
          timestamp: Date.now()
        }));
      }
    }, 30000);
  }

  private scheduleReconnect() {
    if (this.reconnectInterval) return;

    this.reconnectInterval = setInterval(() => {
      if (!this.isConnected) {
        console.log('Attempting to reconnect WebSocket...');
        this.initWebSocket();
      }
    }, 3000);
  }

  private initializeAutoPlay() {
    // Always set auto-play for synchronized start
    setTimeout(() => {
      this.updateState({
        isPlaying: true,
        currentTime: 0
      }, 0);
    }, 500);
  }

  private handleStorageChange(event: StorageEvent) {
    if (event.key === SYNC_KEY && event.newValue) {
      try {
        const state: VideoSyncState = JSON.parse(event.newValue);
        this.notifyListeners(state);
      } catch (error) {
        console.error('Error parsing sync state:', error);
      }
    }
  }

  private handleSyncEvent(event: any) {
    if (event.detail) {
      this.notifyListeners(event.detail);
    }
  }

  private startSyncInterval() {
    // Check for sync updates every 100ms
    this.syncInterval = setInterval(() => {
      const state = this.getCurrentState();
      if (state && Date.now() - state.lastUpdate < 5000) {
        // State is recent, notify listeners
        this.notifyListeners(state);
      }
    }, 100);
  }

  private notifyListeners(state: VideoSyncState) {
    this.listeners.forEach(listener => {
      try {
        listener(state);
      } catch (error) {
        console.error('Error in sync listener:', error);
      }
    });
  }

  public updateState(state: Partial<VideoSyncState>, playerId?: number) {
    const currentState = this.getCurrentState();
    const newState: VideoSyncState = {
      isPlaying: false,
      currentTime: 0,
      lastUpdate: Date.now(),
      ...currentState,
      ...state,
      playerId: playerId || currentState?.playerId
    };

    // Send via WebSocket if connected
    if (this.isConnected && this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify({
          type: newState.isPlaying ? 'play' : 'pause',
          playerId: newState.playerId,
          currentTime: newState.currentTime,
          timestamp: newState.lastUpdate
        }));
      } catch (error) {
        console.error('Error sending WebSocket message:', error);
      }
    }

    // Update localStorage as fallback
    localStorage.setItem(SYNC_KEY, JSON.stringify(newState));

    // Dispatch custom event for same-tab communication
    window.dispatchEvent(new CustomEvent(SYNC_EVENT, { detail: newState }));
  }

  public getCurrentState(): VideoSyncState | null {
    try {
      const stored = localStorage.getItem(SYNC_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch (error) {
      console.error('Error getting sync state:', error);
      return null;
    }
  }

  public subscribe(listener: (state: VideoSyncState) => void) {
    this.listeners.push(listener);

    // Return unsubscribe function
    return () => {
      const index = this.listeners.indexOf(listener);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  public destroy() {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
    }
    if (this.reconnectInterval) {
      clearInterval(this.reconnectInterval);
    }
    if (this.ws) {
      this.ws.close();
    }
    window.removeEventListener('storage', this.handleStorageChange);
    window.removeEventListener(SYNC_EVENT as any, this.handleSyncEvent);
    this.listeners = [];
  }

  public playAll(playerId: number) {
    this.updateState({ 
      isPlaying: true, 
      currentTime: 0 
    }, playerId);
  }

  public pauseAll(playerId: number) {
    this.updateState({ 
      isPlaying: false 
    }, playerId);
  }

  public seekAll(time: number, playerId: number) {
    this.updateState({ 
      currentTime: time,
      isPlaying: true 
    }, playerId);
  }

  public autoStartPlayback(playerId: number) {
    // Automatically start playback when a player loads
    setTimeout(() => {
      const currentState = this.getCurrentState();
      // If no global state exists or all players should auto-start
      if (!currentState || !currentState.isPlaying) {
        this.updateState({ 
          isPlaying: true, 
          currentTime: 0 
        }, playerId);
        console.log(`Auto-starting player ${playerId} with synchronized playback`);
      }
    }, 800); // Reduced delay for faster sync
  }

  public isWebSocketConnected(): boolean {
    return this.isConnected;
  }
}

// Global sync manager instance
export const videoSyncManager = new VideoSyncManager();

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
  videoSyncManager.destroy();
});