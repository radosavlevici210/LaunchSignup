import React, { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Start the application
const rootElement = document.getElementById("root");
if (rootElement) {
  createRoot(rootElement).render(
    <StrictMode>
      <App />
    </StrictMode>
  );
}

console.log('📱 Multi-Player Video Hub - All restrictions removed');
console.log('🌐 All features and access enabled');
console.log('▶️ Auto-play enabled for all media players');