import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Folder, Shuffle } from 'lucide-react';
import { getRandomPlayer, isValidPlayerId } from '@/lib/player-utils';

interface HeaderProps {
  currentPlayerId?: number;
}

export function Header({ currentPlayerId }: HeaderProps) {
  const [location, setLocation] = useLocation();
  const [playerInput, setPlayerInput] = useState('');

  const handleGoToPlayer = () => {
    if (isValidPlayerId(playerInput)) {
      setLocation(`/player/${playerInput}`);
      setPlayerInput('');
    }
  };

  const handleRandomPlayer = () => {
    const randomId = getRandomPlayer();
    setLocation(`/player/${randomId}`);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleGoToPlayer();
    }
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center space-x-4 hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
              <Folder className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-semibold text-gray-900">Multi-Player Hub</h1>
          </Link>
          
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-500">
              {currentPlayerId ? `Player ${currentPlayerId} of 1000` : 'Player 1 of 1000'}
            </span>
            
            <div className="hidden sm:flex items-center space-x-2">
              <Input
                type="number"
                min="1"
                max="1000"
                placeholder="1-1000"
                value={playerInput}
                onChange={(e) => setPlayerInput(e.target.value)}
                onKeyPress={handleKeyPress}
                className="w-24 h-8 text-sm"
              />
              <Button
                onClick={handleGoToPlayer}
                size="sm"
                disabled={!isValidPlayerId(playerInput)}
              >
                Go
              </Button>
            </div>
            
            <Button
              onClick={handleRandomPlayer}
              variant="default"
              size="sm"
              className="flex items-center space-x-1"
            >
              <Shuffle className="w-4 h-4" />
              <span className="hidden sm:inline">Random Player</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
