import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { ChevronLeft, ChevronRight, Share2, Play, Pause, Network, Globe } from 'lucide-react';
import { useLocation } from 'wouter';
import { getYouTubeEmbedUrl, markPlayerVisited, getVirtualNetworkInfo } from '@/lib/player-utils';
import { useToast } from '@/hooks/use-toast';
import { videoSyncManager, VideoSyncState } from '@/lib/video-sync';

interface VideoPlayerProps {
  playerId: number;
}

export function VideoPlayer({ playerId }: VideoPlayerProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [syncState, setSyncState] = useState<VideoSyncState | null>(null);
  const [isLocalPlaying, setIsLocalPlaying] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const networkInfo = getVirtualNetworkInfo(playerId);

  useEffect(() => {
    markPlayerVisited(playerId);

    // Subscribe to video sync updates
    const unsubscribe = videoSyncManager.subscribe((state: VideoSyncState) => {
      setSyncState(state);
      setIsLocalPlaying(state.isPlaying);

      // If this update is from a different player, sync this player
      if (state.playerId !== playerId && iframeRef.current) {
        // Post message to iframe to control playback
        const message = state.isPlaying ? 'play' : 'pause';
        iframeRef.current.contentWindow?.postMessage(`{"event":"command","func":"${message}Video","args":""}`, '*');

        if (state.currentTime > 0) {
          iframeRef.current.contentWindow?.postMessage(`{"event":"command","func":"seekTo","args":[${state.currentTime}, true]}`, '*');
        }
      }
    });

    // Auto-start playback when player loads
    videoSyncManager.autoStartPlayback(playerId);

    // Set initial state
    setIsLocalPlaying(true);

    return unsubscribe;
  }, [playerId]);

  const handlePrevious = () => {
    if (playerId > 1) {
      setLocation(`/player/${playerId - 1}`);
    }
  };

  const handleNext = () => {
    if (playerId < 1000) {
      setLocation(`/player/${playerId + 1}`);
    }
  };

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied!",
        description: "Player URL has been copied to clipboard.",
      });
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Could not copy link to clipboard.",
        variant: "destructive",
      });
    }
  };

  const handlePlayAll = () => {
    setIsLocalPlaying(true);
    videoSyncManager.playAll(playerId);
    toast({
      title: "Play All Triggered",
      description: "All video players will start playing synchronously.",
    });
  };

  const handlePauseAll = () => {
    setIsLocalPlaying(false);
    videoSyncManager.pauseAll(playerId);
    toast({
      title: "Pause All Triggered",
      description: "All video players will pause synchronously.",
    });
  };

  return (
    <Card className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-gray-50 to-gray-100 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xl font-semibold text-gray-900">
              Video Player #{playerId}
            </h3>
            <p className="text-sm text-gray-600 mt-1">
              Unique instance with dedicated routing
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
              Live
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleShare}
              className="p-2 text-gray-400 hover:text-gray-600"
            >
              <Share2 className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Network Information Display */}
        <div className="bg-white rounded-lg p-4 border border-gray-200">
          <div className="flex items-center space-x-2 mb-3">
            <Network className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-semibold text-gray-800">Network Information</span>
          </div>
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-gray-500">IP Address:</span>
              <div className="font-mono font-medium text-gray-900">{networkInfo.ip}</div>
            </div>
            <div>
              <span className="text-gray-500">Port:</span>
              <div className="font-mono font-medium text-gray-900">{networkInfo.port}</div>
            </div>
            <div>
              <span className="text-gray-500">Hostname:</span>
              <div className="font-mono font-medium text-gray-900">{networkInfo.hostname}</div>
            </div>
            <div>
              <span className="text-gray-500">Network ID:</span>
              <div className="font-mono font-medium text-gray-900">{networkInfo.networkId}</div>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-6">
        <div className="video-container mb-6">
          <iframe
            ref={iframeRef}
            src={getYouTubeEmbedUrl()}
            title="YouTube video player"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
          />
        </div>

        {/* Synchronization Controls */}
        <div className="bg-gray-50 rounded-lg p-4 mb-6 border border-gray-200">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <Globe className="w-4 h-4 text-green-600" />
              <span className="text-sm font-semibold text-gray-800">Global Sync Controls</span>
            </div>
            {syncState && (
              <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
                {syncState.isPlaying ? 'Playing' : 'Paused'} 
                {syncState.playerId && ` • Player #${syncState.playerId}`}
              </Badge>
            )}
          </div>
          <div className="flex space-x-3">
            <Button
              onClick={handlePlayAll}
              size="sm"
              className="flex items-center space-x-2 bg-green-600 hover:bg-green-700"
            >
              <Play className="w-4 h-4" />
              <span>Play All Players</span>
            </Button>
            <Button
              onClick={handlePauseAll}
              size="sm"
              variant="outline"
              className="flex items-center space-x-2"
            >
              <Pause className="w-4 h-4" />
              <span>Pause All Players</span>
            </Button>
          </div>
          <p className="text-xs text-gray-500 mt-2">
            Control video playback across all 1000 players simultaneously
          </p>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              onClick={handlePrevious}
              disabled={playerId <= 1}
              className="flex items-center space-x-2"
            >
              <ChevronLeft className="w-4 h-4" />
              <span className="text-sm font-medium">Previous</span>
            </Button>
            <Button
              variant="outline"
              onClick={handleNext}
              disabled={playerId >= 1000}
              className="flex items-center space-x-2"
            >
              <span className="text-sm font-medium">Next</span>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
          <div className="text-sm text-gray-500">
            Player {playerId} of 1000
          </div>
        </div>
      </CardContent>
    </Card>
  );
}