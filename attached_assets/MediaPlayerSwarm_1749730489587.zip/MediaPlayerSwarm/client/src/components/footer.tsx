export function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <p className="text-sm text-gray-500">
            Multi-Player Video Hub - Demonstrating 1000 unique video player instances
          </p>
          <p className="text-xs text-gray-400 mt-2">
            Each player has its own unique route and can be accessed independently
          </p>
        </div>
      </div>
    </footer>
  );
}
