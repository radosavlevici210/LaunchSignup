import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Play, Globe, Pause, Activity } from 'lucide-react';
import { getRandomPlayer, isValidPlayerId, getPlayerStats } from '@/lib/player-utils';
import { videoSyncManager, VideoSyncState } from '@/lib/video-sync';
import { useToast } from '@/hooks/use-toast';

export default function Home() {
  const [selectedPlayers, setSelectedPlayers] = useState<number[]>([]);
  const navigate = useLocation()[1];

  // Generate network info for display
  const networkInfo = {
    virtualIP: generateVirtualIP(),
    realIP: 'Visible to all devices',
    userAgent: navigator.userAgent.substring(0, 50) + '...'
  };

  const handlePlayerSelect = (playerId: number) => {
    setSelectedPlayers(prev => 
      prev.includes(playerId) 
        ? prev.filter(id => id !== playerId)
        : [...prev, playerId]
    );
  };

  const handlePlayAll = () => {
    if (selectedPlayers.length === 0) {
      // Auto-select all players if none selected
      const allPlayers = Array.from({length: 50}, (_, i) => i + 1);
      setSelectedPlayers(allPlayers);
      sessionStorage.setItem('selectedPlayers', JSON.stringify(allPlayers));
      navigate(`/player/1`);
      return;
    }

    // Navigate to first player and store selected players for auto-sync
    sessionStorage.setItem('selectedPlayers', JSON.stringify(selectedPlayers));
    navigate(`/player/${selectedPlayers[0]}`);
  };

  const [, setLocation] = useLocation();
  const [playerInput, setPlayerInput] = useState('');
  const [stats, setStats] = useState(getPlayerStats());
  const [syncState, setSyncState] = useState<VideoSyncState | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const updateStats = () => setStats(getPlayerStats());
    updateStats();

    // Update stats when localStorage changes (in case user visits players in other tabs)
    window.addEventListener('storage', updateStats);

    // Subscribe to video sync updates
    const unsubscribe = videoSyncManager.subscribe((state: VideoSyncState) => {
      setSyncState(state);
    });

    // Get initial sync state
    setSyncState(videoSyncManager.getCurrentState());

    return () => {
      window.removeEventListener('storage', updateStats);
      unsubscribe();
    };
  }, []);

  const handleGoToPlayer = () => {
    if (isValidPlayerId(playerInput)) {
      setLocation(`/player/${playerInput}`);
    }
  };

  const handleRandomPlayer = () => {
    const randomId = getRandomPlayer();
    setLocation(`/player/${randomId}`);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleGoToPlayer();
    }
  };

  const handlePauseAll = () => {
    videoSyncManager.pauseAll(0); // Use 0 for home page trigger
    toast({
      title: "Pause All Triggered", 
      description: "All 1000 video players will pause synchronously.",
    });
  };

  const quickAccessPlayers = Array.from({ length: 12 }, (_, i) => i + 1);

  return (
    <div className="fade-in">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Welcome to Multi-Player Hub
        </h2>
        <p className="text-lg text-gray-600 mb-8">
          Access any of our 1000 unique video players with synchronized playback
        </p>

        {/* Global Sync Status */}
        <Card className="bg-white shadow-sm border border-gray-200 mb-8 max-w-2xl mx-auto">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Globe className="w-5 h-5 text-blue-600" />
                <h3 className="text-lg font-semibold text-gray-900">Global Sync Control</h3>
              </div>
              {syncState && (
                <div className="flex items-center space-x-2">
                  <Badge variant="outline" className={`${syncState.isPlaying ? 'bg-green-100 text-green-800 border-green-200' : 'bg-red-100 text-red-800 border-red-200'}`}>
                    <Activity className="w-3 h-3 mr-1" />
                    {syncState.isPlaying ? 'All Players Active' : 'All Players Paused'}
                  </Badge>
                  <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">
                    {videoSyncManager.isWebSocketConnected() ? 'Network Sync' : 'Local Mode'}
                  </Badge>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="flex space-x-3 justify-center mb-4">
              <Button
                onClick={handlePlayAll}
                className="flex items-center space-x-2 bg-green-600 hover:bg-green-700"
              >
                <Play className="w-4 h-4" />
                <span>Play All 1000 Players</span>
              </Button>
              <Button
                onClick={handlePauseAll}
                variant="outline"
                className="flex items-center space-x-2"
              >
                <Pause className="w-4 h-4" />
                <span>Pause All Players</span>
              </Button>
            </div>
            <p className="text-sm text-gray-600 text-center">
              Control video playback across all players simultaneously. 
              {syncState && syncState.playerId && ` Last action from Player #${syncState.playerId}`}
            </p>
          </CardContent>
        </Card>

        {/* Quick Access Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4 mb-8">
          {quickAccessPlayers.map((playerId) => (
            <Link
              key={playerId}
              href={`/player/${playerId}`}
              className="bg-white border-2 border-gray-200 hover:border-primary hover:bg-blue-50 rounded-xl p-4 transition-all duration-200 group block"
            >
              <div className="w-8 h-8 bg-gradient-to-br from-red-500 to-red-600 rounded-lg mx-auto mb-2 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Play className="w-4 h-4 text-white" />
              </div>
              <span className="text-sm font-medium text-gray-700 group-hover:text-primary">
                Player {playerId}
              </span>
            </Link>
          ))}
        </div>

        {/* Search and Navigation */}
        <div className="max-w-md mx-auto mb-8">
          <div className="relative">
            <Input
              type="number"
              min="1"
              max="1000"
              placeholder="Enter player number (1-1000)"
              value={playerInput}
              onChange={(e) => setPlayerInput(e.target.value)}
              onKeyPress={handleKeyPress}
              className="w-full px-4 py-3 text-center text-lg pr-16"
            />
            <Button
              onClick={handleGoToPlayer}
              disabled={!isValidPlayerId(playerInput)}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 px-4"
              size="sm"
            >
              Go
            </Button>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <Card className="bg-white shadow-sm border border-gray-200">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-primary mb-2">
                {stats.totalPlayers.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Total Players</div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border border-gray-200">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-green-600 mb-2">1</div>
              <div className="text-sm text-gray-600">Video Source</div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm border border-gray-200">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-purple-600 mb-2">
                {stats.visitedCount}
              </div>
              <div className="text-sm text-gray-600">Players Visited</div>
            </CardContent>
          </Card>
        </div>

        {/* Additional Actions */}
        <div className="mt-8">
          <Button
            onClick={handleRandomPlayer}
            variant="outline"
            size="lg"
            className="mx-2"
          >
            Try Random Player
          </Button>
        </div>
      </div>
    </div>
  );
}