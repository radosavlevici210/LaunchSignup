import { useState, useEffect } from 'react';
import { useParams, Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ChevronRight } from 'lucide-react';
import { VideoPlayer } from '@/components/video-player';
import { isValidPlayerId, getRandomPlayer } from '@/lib/player-utils';
import NotFound from './not-found';

export default function Player() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const playerId = parseInt(params.id || '1');

  if (!isValidPlayerId(playerId)) {
    return <NotFound />;
  }

  const handleFirstPlayer = () => setLocation('/player/1');
  const handleLastPlayer = () => setLocation('/player/1000');
  const handleRandomPlayer = () => setLocation(`/player/${getRandomPlayer()}`);

  return (
    <div className="fade-in">
      {/* Breadcrumb Navigation */}
      <nav className="mb-6">
        <div className="flex items-center space-x-2 text-sm">
          <Link href="/" className="text-primary hover:text-blue-700 font-medium">
            Home
          </Link>
          <ChevronRight className="w-4 h-4 text-gray-400" />
          <span className="text-gray-600">Player {playerId}</span>
        </div>
      </nav>

      {/* Player Container */}
      <VideoPlayer playerId={playerId} />

      {/* Additional Player Information */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-white shadow-sm border border-gray-200">
          <CardContent className="p-6">
            <h4 className="font-semibold text-gray-900 mb-3">Player Details</h4>
            <dl className="space-y-2">
              <div className="flex justify-between">
                <dt className="text-sm text-gray-600">Player ID:</dt>
                <dd className="text-sm font-medium text-gray-900">{playerId}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-gray-600">Route:</dt>
                <dd className="text-sm font-medium text-gray-900">/player/{playerId}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-sm text-gray-600">Video URL:</dt>
                <dd className="text-sm font-medium text-gray-900">https://youtu.be/C7Q_Zl8hQkY</dd>
              </div>
            </dl>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border border-gray-200">
          <CardContent className="p-6">
            <h4 className="font-semibold text-gray-900 mb-3">Quick Navigation</h4>
            <div className="space-y-2">
              <Button
                onClick={handleFirstPlayer}
                variant="ghost"
                className="w-full justify-start px-3 py-2 h-auto text-sm"
              >
                Go to First Player (#1)
              </Button>
              <Button
                onClick={handleLastPlayer}
                variant="ghost"
                className="w-full justify-start px-3 py-2 h-auto text-sm"
              >
                Go to Last Player (#1000)
              </Button>
              <Button
                onClick={handleRandomPlayer}
                variant="ghost"
                className="w-full justify-start px-3 py-2 h-auto text-sm"
              >
                Random Player
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
