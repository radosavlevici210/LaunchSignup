
const { spawn } = require('child_process');
const path = require('path');

console.log('🚀 Starting Multi-Player Hub in development mode...\n');

// Start the Express server
const server = spawn('npm', ['run', 'dev'], {
  stdio: 'inherit',
  shell: true,
  cwd: process.cwd()
});

// Start the Vite dev server for the client
const client = spawn('npm', ['run', 'dev'], {
  stdio: 'inherit',
  shell: true,
  cwd: path.join(process.cwd(), 'client')
});

// Handle cleanup
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down development servers...');
  server.kill();
  client.kill();
  process.exit();
});

server.on('error', (err) => {
  console.error('Server error:', err);
});

client.on('error', (err) => {
  console.error('Client error:', err);
});
