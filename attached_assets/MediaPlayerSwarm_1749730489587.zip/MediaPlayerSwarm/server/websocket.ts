import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';

export interface VideoSyncMessage {
  type: 'play' | 'pause' | 'seek' | 'sync_state' | 'heartbeat' | 'auto_start';
  playerId?: number;
  currentTime?: number;
  timestamp: number;
  clientId?: string;
  networkInfo?: {
    ip: string;
    userAgent: string;
    virtualIP?: string;
  };
}

interface ClientInfo {
  ws: WebSocket;
  id: string;
  ip: string;
  virtualIP: string;
  userAgent: string;
  lastHeartbeat: number;
  playerId?: number;
  autoStarted: boolean;
}

export class VideoSyncServer {
  private wss: WebSocketServer;
  private clients: Map<string, ClientInfo> = new Map();
  private currentState: VideoSyncMessage = {
    type: 'pause',
    currentTime: 0,
    timestamp: Date.now()
  };
  private heartbeatInterval: NodeJS.Timeout;

  constructor(server: Server) {
    this.wss = new WebSocketServer({ 
      server,
      path: '/video-sync',
      verifyClient: (info) => {
        console.log(`WebSocket connection from: ${info.origin || 'unknown origin'}`);
        return true;
      }
    });

    // Start heartbeat monitoring
    this.heartbeatInterval = setInterval(() => {
      this.checkHeartbeats();
    }, 30000);

    this.wss.on('connection', (ws: WebSocket, req) => {
      const clientId = this.generateClientId();
      const clientIp = req.socket.remoteAddress || 'unknown';
      const userAgent = req.headers['user-agent'] || 'unknown';
      const virtualIP = this.generateVirtualIP();
      
      console.log(`Video sync client connected - ID: ${clientId}, Real IP: ${clientIp}, Virtual IP: ${virtualIP}`);
      
      const clientInfo: ClientInfo = {
        ws,
        id: clientId,
        ip: clientIp,
        virtualIP,
        userAgent,
        lastHeartbeat: Date.now(),
        autoStarted: false
      };
      
      this.clients.set(clientId, clientInfo);

      // Send current state to new client with network info including virtual IP
      const welcomeMessage = {
        ...this.currentState,
        clientId,
        networkInfo: { 
          ip: clientIp, 
          userAgent,
          virtualIP 
        }
      };
      ws.send(JSON.stringify(welcomeMessage));

      // Auto-start playback after 2 seconds
      setTimeout(() => {
        if (!clientInfo.autoStarted && this.clients.has(clientId)) {
          const autoStartMessage: VideoSyncMessage = {
            type: 'auto_start',
            playerId: clientInfo.playerId,
            currentTime: 0,
            timestamp: Date.now(),
            clientId,
            networkInfo: { 
              ip: clientIp, 
              userAgent,
              virtualIP 
            }
          };
          
          // Send auto-start to this client
          ws.send(JSON.stringify(autoStartMessage));
          clientInfo.autoStarted = true;
          
          console.log(`Auto-started player for client ${clientId} with virtual IP ${virtualIP}`);
        }
      }, 2000);

      ws.on('message', (data: Buffer) => {
        try {
          const message: VideoSyncMessage = JSON.parse(data.toString());
          message.clientId = clientId;
          message.networkInfo = { ip: clientIp, userAgent };
          this.handleMessage(message, clientId);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      });

      ws.on('close', () => {
        console.log(`Video sync client disconnected - ID: ${clientId}, IP: ${clientIp}`);
        this.clients.delete(clientId);
      });

      ws.on('error', (error) => {
        console.error(`WebSocket error for client ${clientId}:`, error);
        this.clients.delete(clientId);
      });

      // Send heartbeat ping
      ws.ping();
    });
  }

  private generateClientId(): string {
    return Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
  }

  private generateVirtualIP(): string {
    // Generate unique virtual IP for each client (192.168.x.x range)
    const subnet = Math.floor(Math.random() * 255) + 1;
    const host = Math.floor(Math.random() * 254) + 1;
    return `192.168.${subnet}.${host}`;
  }

  private checkHeartbeats() {
    const now = Date.now();
    const staleClients: string[] = [];
    
    this.clients.forEach((client, clientId) => {
      if (now - client.lastHeartbeat > 60000) { // 60 seconds timeout
        console.log(`Removing stale client: ${clientId}`);
        staleClients.push(clientId);
        client.ws.terminate();
      }
    });
    
    staleClients.forEach(clientId => this.clients.delete(clientId));
  }

  private handleMessage(message: VideoSyncMessage, senderClientId: string) {
    const senderInfo = this.clients.get(senderClientId);
    if (!senderInfo) return;

    // Update heartbeat for sender
    senderInfo.lastHeartbeat = Date.now();

    // Handle heartbeat messages
    if (message.type === 'heartbeat') {
      return;
    }

    // Update current state
    this.currentState = {
      ...message,
      timestamp: Date.now()
    };

    console.log(`Broadcasting sync from ${senderInfo.ip} (Player ${message.playerId}): ${message.type} - Active clients: ${this.clients.size}`);

    // Broadcast to all clients except sender
    const messageStr = JSON.stringify(this.currentState);
    this.clients.forEach((client, clientId) => {
      if (clientId !== senderClientId && client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(messageStr);
      }
    });
  }

  public getCurrentState(): VideoSyncMessage {
    return this.currentState;
  }

  public getConnectedClients(): Array<{id: string, ip: string, userAgent: string}> {
    return Array.from(this.clients.values()).map(client => ({
      id: client.id,
      ip: client.ip,
      userAgent: client.userAgent
    }));
  }

  public destroy() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }
    this.clients.forEach(client => client.ws.terminate());
    this.clients.clear();
    this.wss.close();
  }
}