import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface MovieGenerationRequest {
  script: string;
  genre: string;
}

export interface MusicGenerationRequest {
  description: string;
  tempo: number;
  energy: number;
}

export async function generateMovieScript(data: MovieGenerationRequest) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are a professional movie script generator. Create detailed movie scripts with scene descriptions, dialogue, and production notes. Format the output as JSON with the following structure: {
            "title": "Movie Title",
            "genre": "Genre",
            "duration": "Estimated duration in minutes",
            "scenes": [
              {
                "scene_number": 1,
                "location": "Scene location",
                "time": "Time of day",
                "description": "Scene description",
                "dialogue": ["Character: Line", "Character: Line"],
                "camera_notes": "Camera and direction notes"
              }
            ],
            "production_notes": "Overall production guidance"
          }`
        },
        {
          role: "user",
          content: `Generate a ${data.genre} movie script based on this concept: ${data.script}`
        }
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    throw new Error(`Failed to generate movie script: ${error.message}`);
  }
}

export async function generateMusicComposition(data: MusicGenerationRequest) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are a professional music composer and producer. Create detailed music compositions with chord progressions, melodies, and production notes. Format the output as JSON with the following structure: {
            "title": "Track Title",
            "tempo": number,
            "key": "Musical key",
            "time_signature": "Time signature",
            "duration": "Track duration in minutes",
            "structure": [
              {
                "section": "intro/verse/chorus/bridge/outro",
                "duration": "Section duration in seconds",
                "chords": ["C", "Am", "F", "G"],
                "melody_notes": "Melody description",
                "instruments": ["piano", "guitar", "drums"],
                "production_notes": "Production guidance"
              }
            ],
            "overall_mood": "Description of the overall mood and feel",
            "mixing_notes": "Audio mixing and mastering guidance"
          }`
        },
        {
          role: "user",
          content: `Generate a music composition based on this description: ${data.description}. Tempo should be around ${data.tempo} BPM with an energy level of ${data.energy}/10.`
        }
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    throw new Error(`Failed to generate music composition: ${error.message}`);
  }
}

export async function generateProjectAnalysis(projectData: any) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `You are an AI assistant that analyzes creative projects and provides insights. Analyze the project data and provide feedback in JSON format: {
            "quality_score": number (1-10),
            "strengths": ["strength1", "strength2"],
            "improvements": ["suggestion1", "suggestion2"],
            "market_potential": "Assessment of commercial viability",
            "technical_analysis": "Technical quality assessment",
            "creative_score": number (1-10)
          }`
        },
        {
          role: "user",
          content: `Analyze this creative project: ${JSON.stringify(projectData)}`
        }
      ],
      response_format: { type: "json_object" },
    });

    return JSON.parse(response.choices[0].message.content || "{}");
  } catch (error) {
    throw new Error(`Failed to analyze project: ${error.message}`);
  }
}
