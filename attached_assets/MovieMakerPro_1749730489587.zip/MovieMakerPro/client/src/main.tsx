import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

document.title = "AI Movie & Music Studio Pro+ - Enhanced Professional Production | Ervin Radosavlevici";

createRoot(document.getElementById("root")!).render(<App />);
