import { useState } from "react";
import { Video, Play, SkipBack, SkipForward, Pause } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function VideoEditor() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(25); // percentage

  const timeMarkers = [
    "00:00", "00:30", "01:00", "01:30", "02:00", "02:30",
    "03:00", "03:30", "04:00", "04:30", "05:00", "05:30"
  ];

  return (
    <div className="glass-card rounded-3xl p-8 mb-12">
      <div className="flex items-center mb-6">
        <Video className="text-5xl text-[#0099ff] mr-6" size={48} />
        <h2 className="text-3xl font-bold">Professional Video Editor</h2>
      </div>
      
      {/* Modern video editing interface */}
      <img 
        src="https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&h=400" 
        alt="Professional video editing setup" 
        className="w-full h-64 object-cover rounded-xl mb-6" 
      />
      
      {/* Timeline Interface */}
      <div className="bg-black/60 rounded-xl p-6">
        <div className="grid grid-cols-12 gap-1 mb-4">
          {timeMarkers.map((time, index) => (
            <div key={index} className="text-sm text-gray-400">{time}</div>
          ))}
        </div>
        
        {/* Video Tracks */}
        <div className="space-y-2">
          <div className="flex items-center">
            <div className="w-20 text-sm text-[#00ff88]">Video 1</div>
            <div className="flex-1 h-8 bg-gradient-to-r from-[#00ff88] to-[#0099ff] rounded relative">
              <div className="absolute inset-y-0 left-1/4 w-0.5 bg-white opacity-75"></div>
            </div>
          </div>
          <div className="flex items-center">
            <div className="w-20 text-sm text-[#0099ff]">Audio 1</div>
            <div className="flex-1 h-6 bg-gradient-to-r from-[#0099ff] to-[#ff0080] rounded relative">
              <div className="absolute inset-y-0 left-1/3 w-0.5 bg-white opacity-75"></div>
            </div>
          </div>
          <div className="flex items-center">
            <div className="w-20 text-sm text-[#ff0080]">Effects</div>
            <div className="flex-1 h-4 bg-gradient-to-r from-[#ff0080] to-[#ffaa00] rounded"></div>
          </div>
        </div>
        
        {/* Playhead */}
        <div className="relative mt-4">
          <div className="w-full h-1 bg-white/20 rounded"></div>
          <div 
            className="absolute top-0 w-0.5 h-8 bg-white transform -translate-y-3 transition-all duration-300"
            style={{ left: `${currentTime}%` }}
          ></div>
        </div>
      </div>
      
      {/* Video Controls */}
      <div className="flex justify-center items-center space-x-6 mt-6">
        <Button
          variant="ghost"
          size="icon"
          className="w-12 h-12 bg-gradient-to-r from-[#00ff88] to-[#0099ff] rounded-full hover:scale-110 transition-all"
        >
          <SkipBack size={20} />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsPlaying(!isPlaying)}
          className="w-16 h-16 bg-gradient-to-r from-[#ff0080] to-purple-600 rounded-full hover:scale-110 transition-all"
        >
          {isPlaying ? <Pause size={24} /> : <Play size={24} />}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="w-12 h-12 bg-gradient-to-r from-[#00ff88] to-[#0099ff] rounded-full hover:scale-110 transition-all"
        >
          <SkipForward size={20} />
        </Button>
      </div>
    </div>
  );
}
