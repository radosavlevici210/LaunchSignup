import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { 
  GraduationCap,
  BookOpen,
  Video,
  Users,
  Award,
  Target,
  Brain,
  Lightbulb,
  Zap,
  Star,
  Clock,
  PlayCircle,
  Download,
  Share2,
  Trophy,
  FileText,
  Calendar,
  MessageCircle,
  HeadphonesIcon,
  MonitorPlay,
  Gamepad2,
  Settings
} from "lucide-react";

interface Course {
  id: string;
  title: string;
  description: string;
  level: 'beginner' | 'intermediate' | 'advanced' | 'master';
  duration: string;
  modules: number;
  progress: number;
  category: string;
  instructor: string;
  rating: number;
  students: number;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress: number;
  requirement: string;
}

export default function EducationalHub() {
  const [selectedCourse, setSelectedCourse] = useState<string>("");
  const [learningProgress, setLearningProgress] = useState(67);
  const [currentModule, setCurrentModule] = useState("AI Video Production Basics");
  const [studyStreak, setStudyStreak] = useState(15);

  const courses: Course[] = [
    {
      id: 'ai-filmmaking',
      title: 'AI Filmmaking Masterclass',
      description: 'Learn professional movie production with AI tools',
      level: 'intermediate',
      duration: '8 hours',
      modules: 12,
      progress: 75,
      category: 'Video Production',
      instructor: 'Prof. Cinema AI',
      rating: 4.9,
      students: 2847
    },
    {
      id: 'music-composition',
      title: 'AI Music Composition',
      description: 'Create professional music with AI assistance',
      level: 'beginner',
      duration: '6 hours',
      modules: 10,
      progress: 45,
      category: 'Music Production',
      instructor: 'Maestro Digital',
      rating: 4.8,
      students: 1952
    },
    {
      id: 'voice-synthesis',
      title: 'Voice Synthesis & Cloning',
      description: 'Master professional voice generation techniques',
      level: 'advanced',
      duration: '10 hours',
      modules: 15,
      progress: 30,
      category: 'Voice Technology',
      instructor: 'Dr. Voice Tech',
      rating: 4.9,
      students: 1243
    },
    {
      id: 'business-production',
      title: 'Business of AI Production',
      description: 'Monetize your AI-generated content',
      level: 'intermediate',
      duration: '5 hours',
      modules: 8,
      progress: 90,
      category: 'Business',
      instructor: 'CEO Success',
      rating: 4.7,
      students: 3421
    },
    {
      id: 'technical-mastery',
      title: 'Technical AI Mastery',
      description: 'Deep dive into AI algorithms and optimization',
      level: 'master',
      duration: '20 hours',
      modules: 25,
      progress: 15,
      category: 'Technical',
      instructor: 'AI Research Lab',
      rating: 4.9,
      students: 567
    },
    {
      id: 'creative-storytelling',
      title: 'Creative AI Storytelling',
      description: 'Craft compelling narratives with AI assistance',
      level: 'beginner',
      duration: '7 hours',
      modules: 11,
      progress: 60,
      category: 'Creative Writing',
      instructor: 'Story Master',
      rating: 4.8,
      students: 2156
    }
  ];

  const achievements: Achievement[] = [
    {
      id: 'first-movie',
      title: 'First Movie Creator',
      description: 'Created your first AI-generated movie',
      icon: '🎬',
      unlocked: true,
      progress: 100,
      requirement: 'Complete 1 movie project'
    },
    {
      id: 'music-maestro',
      title: 'Music Maestro',
      description: 'Produced 10 professional music tracks',
      icon: '🎵',
      unlocked: true,
      progress: 100,
      requirement: 'Create 10 music tracks'
    },
    {
      id: 'learning-streak',
      title: 'Learning Streak Champion',
      description: 'Maintained 30-day learning streak',
      icon: '🔥',
      unlocked: false,
      progress: 50,
      requirement: 'Study 30 days consecutively'
    },
    {
      id: 'ai-expert',
      title: 'AI Production Expert',
      description: 'Mastered all production techniques',
      icon: '🧠',
      unlocked: false,
      progress: 75,
      requirement: 'Complete all courses'
    },
    {
      id: 'community-leader',
      title: 'Community Leader',
      description: 'Helped 100+ students in forums',
      icon: '👥',
      unlocked: false,
      progress: 25,
      requirement: 'Help 100 students'
    },
    {
      id: 'master-creator',
      title: 'Master Creator',
      description: 'Created content across all categories',
      icon: '🏆',
      unlocked: false,
      progress: 80,
      requirement: 'Create in all categories'
    }
  ];

  const learningPaths = [
    {
      title: 'Complete Beginner',
      description: 'Start your AI production journey',
      courses: ['music-composition', 'creative-storytelling', 'ai-filmmaking'],
      duration: '21 hours',
      students: 5432
    },
    {
      title: 'Professional Creator',
      description: 'Advanced production techniques',
      courses: ['ai-filmmaking', 'voice-synthesis', 'business-production'],
      duration: '23 hours',
      students: 2156
    },
    {
      title: 'Technical Expert',
      description: 'Master the technology behind AI',
      courses: ['technical-mastery', 'voice-synthesis', 'ai-filmmaking'],
      duration: '38 hours',
      students: 843
    },
    {
      title: 'Business Focused',
      description: 'Monetize your AI creations',
      courses: ['business-production', 'ai-filmmaking', 'music-composition'],
      duration: '19 hours',
      students: 3278
    }
  ];

  const handleStartCourse = (courseId: string) => {
    setSelectedCourse(courseId);
    alert(`🎓 Starting course: ${courses.find(c => c.id === courseId)?.title}\n\n• Interactive lessons\n• Hands-on projects\n• Expert guidance\n• Community support\n• Certificate upon completion`);
  };

  const handleDownloadCertificate = () => {
    const certificates = [
      'AI Movie Producer Certificate',
      'Music Production Master Certificate',
      'Professional AI Certificate Bundle',
      'Industry Recognition Document',
      'Advanced Video Editing Certificate',
      'Voice Synthesis Expert Certificate',
      'Creative Storytelling Master Certificate'
    ];
    
    alert(`🏆 Certificates Downloaded!\n\n${certificates.map(cert => `• ${cert}`).join('\n')}\n\n• PDF format ready\n• LinkedIn integration available\n• Industry recognized credentials\n• Blockchain verified authenticity\n• NFT certificate option\n• Global accreditation\n• Portfolio integration ready`);
  };

  const handleStartLiveClass = () => {
    alert('🎥 Live Class Starting!\n\n• Interactive HD video session\n• Real-time Q&A\n• Screen sharing enabled\n• Recording available\n• Expert instructor\n• Community chat\n• Hands-on exercises\n• Certificate upon completion');
  };

  const handleJoinCommunity = () => {
    alert('👥 Welcome to AI Creator Community!\n\n• Connect with 10,000+ creators\n• Share your projects\n• Get feedback and tips\n• Collaborate on projects\n• Access exclusive resources');
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'beginner': return 'text-green-400 bg-green-500/20';
      case 'intermediate': return 'text-blue-400 bg-blue-500/20';
      case 'advanced': return 'text-orange-400 bg-orange-500/20';
      case 'master': return 'text-purple-400 bg-purple-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  return (
    <div className="space-y-6">
      {/* Learning Dashboard */}
      <Card className="glass-card border-[#00ff88]/30">
        <CardHeader>
          <CardTitle className="text-[#00ff88] flex items-center gap-2">
            <GraduationCap size={20} />
            AI Production Academy - Educational Hub
          </CardTitle>
          <CardDescription>
            Master AI production with comprehensive courses, certifications, and community support
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-[#00ff88]">{learningProgress}%</div>
              <div className="text-sm text-gray-400">Overall Progress</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#0099ff]">{studyStreak}</div>
              <div className="text-sm text-gray-400">Day Streak</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#ff0080]">12</div>
              <div className="text-sm text-gray-400">Courses</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#ffaa00]">89</div>
              <div className="text-sm text-gray-400">Modules</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#00ffff]">6</div>
              <div className="text-sm text-gray-400">Certificates</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#32cd32]">4.9</div>
              <div className="text-sm text-gray-400">Avg Rating</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="courses" className="w-full">
        <TabsList className="grid w-full grid-cols-5 glass-card">
          <TabsTrigger value="courses">Courses</TabsTrigger>
          <TabsTrigger value="paths">Learning Paths</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="community">Community</TabsTrigger>
          <TabsTrigger value="certificates">Certificates</TabsTrigger>
        </TabsList>

        <TabsContent value="courses" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map((course) => (
              <Card key={course.id} className="glass-card border-white/10 hover:border-[#00ff88]/30 transition-colors">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between mb-2">
                    <Badge className={getLevelColor(course.level)}>
                      {course.level}
                    </Badge>
                    <div className="flex items-center gap-1">
                      <Star size={14} className="text-yellow-400" />
                      <span className="text-sm">{course.rating}</span>
                    </div>
                  </div>
                  <CardTitle className="text-sm">{course.title}</CardTitle>
                  <CardDescription className="text-xs">
                    {course.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between text-xs text-gray-400">
                    <span>{course.duration}</span>
                    <span>{course.modules} modules</span>
                    <span>{course.students.toLocaleString()} students</span>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span>Progress</span>
                      <span>{course.progress}%</span>
                    </div>
                    <Progress value={course.progress} className="h-2" />
                  </div>

                  <div className="text-xs">
                    <span className="text-[#00ff88]">Instructor:</span> {course.instructor}
                  </div>

                  <div className="space-y-2">
                    <Button 
                      size="sm" 
                      className="w-full bg-gradient-to-r from-[#00ff88] to-[#0099ff] hover:from-[#00cc6a] hover:to-[#0077cc]"
                      onClick={() => handleStartCourse(course.id)}
                    >
                      <PlayCircle size={14} className="mr-1" />
                      {course.progress > 0 ? 'Continue' : 'Start Course'}
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="w-full border-red-500/30 text-red-400 hover:bg-red-500/10"
                      onClick={handleStartLiveClass}
                    >
                      <Video size={14} className="mr-1" />
                      Join Live Class
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="paths" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {learningPaths.map((path, index) => (
              <Card key={index} className="glass-card border-[#0099ff]/20">
                <CardHeader>
                  <CardTitle className="text-[#0099ff] flex items-center gap-2">
                    <Target size={20} />
                    {path.title}
                  </CardTitle>
                  <CardDescription>{path.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between text-sm">
                    <span>Duration: <span className="text-[#00ff88]">{path.duration}</span></span>
                    <span>Students: <span className="text-[#ff0080]">{path.students.toLocaleString()}</span></span>
                  </div>

                  <div>
                    <div className="text-sm font-medium text-[#0099ff] mb-2">Included Courses:</div>
                    <div className="space-y-1">
                      {path.courses.map((courseId) => {
                        const course = courses.find(c => c.id === courseId);
                        return (
                          <div key={courseId} className="flex items-center justify-between text-xs">
                            <span>{course?.title}</span>
                            <Badge variant="outline" className="text-xs">
                              {course?.duration}
                            </Badge>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-[#0099ff] to-[#00ffff]">
                    <Target size={16} className="mr-2" />
                    Start Learning Path
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {achievements.map((achievement) => (
              <Card 
                key={achievement.id} 
                className={`glass-card ${achievement.unlocked ? 'border-[#00ff88]/30' : 'border-gray-500/20'} transition-colors`}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="text-2xl">{achievement.icon}</div>
                    <div className="flex-1">
                      <div className={`font-medium ${achievement.unlocked ? 'text-[#00ff88]' : 'text-gray-400'}`}>
                        {achievement.title}
                      </div>
                      <div className="text-xs text-gray-400">{achievement.description}</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span>{achievement.requirement}</span>
                      <span>{achievement.progress}%</span>
                    </div>
                    <Progress value={achievement.progress} className="h-2" />
                  </div>

                  {achievement.unlocked && (
                    <Badge className="w-full justify-center mt-2 bg-green-500/20 text-green-400">
                      ✓ Unlocked
                    </Badge>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="community" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="glass-card border-[#ff0080]/20">
              <CardHeader>
                <CardTitle className="text-[#ff0080] flex items-center gap-2">
                  <Users size={20} />
                  Community Hub
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-[#00ff88]">10,247</div>
                    <div className="text-sm text-gray-400">Active Members</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-[#0099ff]">1,856</div>
                    <div className="text-sm text-gray-400">Projects Shared</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-[#ffaa00]">24/7</div>
                    <div className="text-sm text-gray-400">Support Available</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-[#00ffff]">92%</div>
                    <div className="text-sm text-gray-400">Success Rate</div>
                  </div>
                </div>

                <Button 
                  className="w-full bg-gradient-to-r from-[#ff0080] to-[#8000ff]"
                  onClick={handleJoinCommunity}
                >
                  <Users size={16} className="mr-2" />
                  Join Community
                </Button>
              </CardContent>
            </Card>

            <Card className="glass-card border-[#ffaa00]/20">
              <CardHeader>
                <CardTitle className="text-[#ffaa00] flex items-center gap-2">
                  <Lightbulb size={20} />
                  Featured Discussions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  {[
                    { title: 'Best AI Models for Movie Production', replies: 156, category: 'Movies' },
                    { title: 'Music Distribution Strategy 2024', replies: 89, category: 'Music' },
                    { title: 'Voice Cloning Ethics Discussion', replies: 234, category: 'Voice' },
                    { title: 'Monetization Success Stories', replies: 67, category: 'Business' }
                  ].map((topic, index) => (
                    <div key={index} className="p-2 bg-white/5 rounded text-sm">
                      <div className="font-medium">{topic.title}</div>
                      <div className="flex justify-between text-xs text-gray-400">
                        <span>{topic.category}</span>
                        <span>{topic.replies} replies</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="certificates" className="space-y-6">
          <Card className="glass-card border-[#32cd32]/20">
            <CardHeader>
              <CardTitle className="text-[#32cd32] flex items-center gap-2">
                <FileText size={20} />
                Professional Certifications
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { name: 'AI Movie Producer', status: 'Earned', date: '2024-01-15', level: 'Professional' },
                  { name: 'Music Production Master', status: 'Earned', date: '2024-01-20', level: 'Advanced' },
                  { name: 'Voice Technology Expert', status: 'In Progress', date: null, level: 'Expert' },
                  { name: 'Business Strategy Specialist', status: 'Available', date: null, level: 'Intermediate' }
                ].map((cert, index) => (
                  <div key={index} className="p-4 bg-white/5 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="font-medium">{cert.name}</div>
                      <Badge 
                        className={
                          cert.status === 'Earned' ? 'bg-green-500/20 text-green-400' :
                          cert.status === 'In Progress' ? 'bg-blue-500/20 text-blue-400' :
                          'bg-gray-500/20 text-gray-400'
                        }
                      >
                        {cert.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-400 mb-2">Level: {cert.level}</div>
                    {cert.date && (
                      <div className="text-xs text-gray-400">Earned: {cert.date}</div>
                    )}
                  </div>
                ))}
              </div>

              <div className="text-center">
                <Button 
                  className="bg-gradient-to-r from-[#32cd32] to-[#228b22]"
                  onClick={handleDownloadCertificate}
                >
                  <Download size={16} className="mr-2" />
                  Download Certificates
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}