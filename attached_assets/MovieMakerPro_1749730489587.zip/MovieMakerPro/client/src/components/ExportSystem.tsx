import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Download, Video, Music, Film, FileText, Settings, Cloud, Zap } from "lucide-react";

export default function ExportSystem() {
  const [exportProgress, setExportProgress] = useState(0);
  const [isExporting, setIsExporting] = useState(false);
  const [selectedFormat, setSelectedFormat] = useState("mp4");
  const [selectedQuality, setSelectedQuality] = useState("1080p");

  const handleExport = () => {
    setIsExporting(true);
    setExportProgress(0);
    
    const interval = setInterval(() => {
      setExportProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsExporting(false);
          return 100;
        }
        return prev + 10;
      });
    }, 500);
  };

  const exportFormats = {
    video: [
      { value: "mp4", label: "MP4 (Universal)", description: "Best for web and mobile" },
      { value: "mov", label: "MOV (Professional)", description: "High quality for editing" },
      { value: "avi", label: "AVI (Legacy)", description: "Older format compatibility" },
      { value: "webm", label: "WebM (Web)", description: "Optimized for streaming" },
    ],
    audio: [
      { value: "mp3", label: "MP3 (Standard)", description: "Compressed audio" },
      { value: "wav", label: "WAV (Uncompressed)", description: "Studio quality" },
      { value: "flac", label: "FLAC (Lossless)", description: "Perfect quality" },
      { value: "aac", label: "AAC (Mobile)", description: "Optimized for devices" },
    ],
    script: [
      { value: "pdf", label: "PDF (Standard)", description: "Professional formatting" },
      { value: "fdx", label: "Final Draft", description: "Industry standard" },
      { value: "fountain", label: "Fountain", description: "Plain text format" },
      { value: "docx", label: "Word Document", description: "General purpose" },
    ]
  };

  const qualityOptions = [
    { value: "4k", label: "4K Ultra HD", bitrate: "50 Mbps" },
    { value: "1080p", label: "Full HD 1080p", bitrate: "25 Mbps" },
    { value: "720p", label: "HD 720p", bitrate: "12 Mbps" },
    { value: "480p", label: "SD 480p", bitrate: "5 Mbps" },
  ];

  return (
    <div className="space-y-6">
      <Card className="glass-card border-[#00ff88]/30">
        <CardHeader>
          <CardTitle className="text-[#00ff88] flex items-center gap-2">
            <Download size={20} />
            Professional Export System
          </CardTitle>
          <CardDescription>Export your projects in professional formats</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="video" className="w-full">
            <TabsList className="grid w-full grid-cols-3 glass-card">
              <TabsTrigger value="video" className="flex items-center gap-2">
                <Video size={16} />
                Video
              </TabsTrigger>
              <TabsTrigger value="audio" className="flex items-center gap-2">
                <Music size={16} />
                Audio
              </TabsTrigger>
              <TabsTrigger value="script" className="flex items-center gap-2">
                <FileText size={16} />
                Script
              </TabsTrigger>
            </TabsList>

            {Object.entries(exportFormats).map(([type, formats]) => (
              <TabsContent key={type} value={type} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-[#00ff88]">Format</label>
                    <Select value={selectedFormat} onValueChange={setSelectedFormat}>
                      <SelectTrigger className="glass-input">
                        <SelectValue placeholder="Select format" />
                      </SelectTrigger>
                      <SelectContent>
                        {formats.map((format) => (
                          <SelectItem key={format.value} value={format.value}>
                            <div>
                              <div className="font-medium">{format.label}</div>
                              <div className="text-xs text-gray-400">{format.description}</div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {type === "video" && (
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-[#0099ff]">Quality</label>
                      <Select value={selectedQuality} onValueChange={setSelectedQuality}>
                        <SelectTrigger className="glass-input">
                          <SelectValue placeholder="Select quality" />
                        </SelectTrigger>
                        <SelectContent>
                          {qualityOptions.map((quality) => (
                            <SelectItem key={quality.value} value={quality.value}>
                              <div className="flex justify-between items-center w-full">
                                <span>{quality.label}</span>
                                <Badge variant="outline" className="ml-2 text-xs">
                                  {quality.bitrate}
                                </Badge>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 glass-card rounded-lg">
                  <div className="text-center">
                    <div className="text-lg font-bold text-[#00ff88]">98.7%</div>
                    <div className="text-xs text-gray-400">Compression Efficiency</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-[#0099ff]">2.3s</div>
                    <div className="text-xs text-gray-400">Estimated Time</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-[#ff0080]">245MB</div>
                    <div className="text-xs text-gray-400">Output Size</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-[#ffaa00]">Pro+</div>
                    <div className="text-xs text-gray-400">Quality Level</div>
                  </div>
                </div>
              </TabsContent>
            ))}
          </Tabs>

          {isExporting && (
            <div className="space-y-3 mt-6">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Exporting...</span>
                <span className="text-sm text-gray-400">{exportProgress}%</span>
              </div>
              <Progress value={exportProgress} className="h-2" />
              <div className="text-xs text-gray-400 text-center">
                AI-powered optimization in progress
              </div>
            </div>
          )}

          <div className="flex gap-3 mt-6">
            <Button 
              onClick={handleExport}
              disabled={isExporting}
              className="flex-1 bg-gradient-to-r from-[#00ff88] to-[#0099ff] hover:from-[#00cc6a] hover:to-[#0077cc] text-black font-semibold"
            >
              <Download size={16} className="mr-2" />
              {isExporting ? "Exporting..." : "Export Project"}
            </Button>
            <Button variant="outline" className="glass-input border-[#00ff88]/30">
              <Settings size={16} className="mr-2" />
              Advanced
            </Button>
            <Button variant="outline" className="glass-input border-[#0099ff]/30">
              <Cloud size={16} className="mr-2" />
              Cloud Export
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
            <Card className="glass-card border-[#00ff88]/20">
              <CardContent className="p-4 text-center">
                <Zap className="w-8 h-8 text-[#00ff88] mx-auto mb-2" />
                <div className="font-semibold text-sm">Instant Export</div>
                <div className="text-xs text-gray-400">AI-accelerated processing</div>
              </CardContent>
            </Card>
            <Card className="glass-card border-[#0099ff]/20">
              <CardContent className="p-4 text-center">
                <Cloud className="w-8 h-8 text-[#0099ff] mx-auto mb-2" />
                <div className="font-semibold text-sm">Cloud Storage</div>
                <div className="text-xs text-gray-400">Automatic backup</div>
              </CardContent>
            </Card>
            <Card className="glass-card border-[#ff0080]/20">
              <CardContent className="p-4 text-center">
                <Film className="w-8 h-8 text-[#ff0080] mx-auto mb-2" />
                <div className="font-semibold text-sm">Pro Quality</div>
                <div className="text-xs text-gray-400">Industry standards</div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}