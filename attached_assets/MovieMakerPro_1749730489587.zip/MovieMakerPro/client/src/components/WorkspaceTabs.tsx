import { useState } from "react";
import { Film, Music, Video, BarChart3, Settings, Folder, Brain, Users, GraduationCap } from "lucide-react";

interface WorkspaceTabsProps {
  activeWorkspace: string;
  onWorkspaceChange: (workspace: string) => void;
}

export default function WorkspaceTabs({ activeWorkspace, onWorkspaceChange }: WorkspaceTabsProps) {
  const tabs = [
    { id: "workspace", label: "Projects", icon: Folder },
    { id: "movie", label: "Movie Studio", icon: Film },
    { id: "music", label: "Music Studio", icon: Music },
    { id: "video", label: "Video Editor", icon: Video },
    { id: "analytics", label: "AI Analytics", icon: Brain },
    { id: "tools", label: "Pro Tools", icon: Settings },
    { id: "collaboration", label: "Collaborate", icon: Users },
    { id: "education", label: "Education", icon: GraduationCap },
  ];

  return (
    <div className="flex bg-black/30 rounded-2xl mb-8 overflow-hidden">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        return (
          <button
            key={tab.id}
            onClick={() => onWorkspaceChange(tab.id)}
            className={`flex-1 flex items-center justify-center gap-2 py-4 px-6 transition-all duration-300 ${
              activeWorkspace === tab.id
                ? "bg-[#00ff88]/20 border-b-4 border-[#00ff88] text-white"
                : "text-gray-400 hover:bg-[#00ff88]/10 hover:text-white"
            }`}
          >
            <Icon size={20} />
            <span className="font-medium hidden md:inline">{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
}