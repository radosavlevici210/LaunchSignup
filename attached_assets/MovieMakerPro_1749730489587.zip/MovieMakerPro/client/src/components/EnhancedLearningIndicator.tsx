import { Brain } from "lucide-react";

export default function EnhancedLearningIndicator() {
  return (
    <div className="glass-card rounded-3xl p-8 mb-8 border-2 border-[#00ff88]/30">
      <div className="text-center mb-6">
        <h3 className="text-2xl font-bold text-[#00ff88] mb-4 flex items-center justify-center gap-3">
          <Brain size={32} />
          Enhanced AI Self-Learning System
        </h3>
        <p className="text-gray-300">Advanced AI with multi-model selection, real-time optimization, and collaborative learning</p>
      </div>
      
      <div className="w-full h-3 bg-white/10 rounded-full overflow-hidden mb-4">
        <div className="h-full bg-gradient-to-r from-[#00ff88] via-[#0099ff] to-[#ff0080] rounded-full animate-learning-pulse"></div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
        <div className="text-center">
          <span className="text-gray-400">Learning Speed:</span>
          <div className="font-bold text-[#00ff88]">Quantum Mode</div>
        </div>
        <div className="text-center">
          <span className="text-gray-400">Intelligence Level:</span>
          <div className="font-bold text-[#0099ff]">Advanced+</div>
        </div>
        <div className="text-center">
          <span className="text-gray-400">Optimization:</span>
          <div className="font-bold text-[#ff0080]">99.7%</div>
        </div>
        <div className="text-center">
          <span className="text-gray-400">Models Active:</span>
          <div className="font-bold text-[#ffaa00]">12</div>
        </div>
      </div>
    </div>
  );
}