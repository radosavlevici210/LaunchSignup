
import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { 
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  Download,
  Share2,
  Settings,
  List,
  Repeat,
  Shuffle,
  Heart,
  MoreVertical
} from "lucide-react";

interface MediaItem {
  id: string;
  title: string;
  type: 'video' | 'audio';
  duration: string;
  thumbnail?: string;
  url: string;
  artist?: string;
}

export default function MediaPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(80);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [currentMedia, setCurrentMedia] = useState<MediaItem | null>(null);
  const [playlist, setPlaylist] = useState<MediaItem[]>([]);

  const mediaRef = useRef<HTMLVideoElement | HTMLAudioElement>(null);

  const samplePlaylist: MediaItem[] = [
    {
      id: '1',
      title: 'AI Revolution - Trailer',
      type: 'video',
      duration: '2:30',
      thumbnail: '/api/placeholder/320/180',
      url: '/media/sample-video.mp4',
      artist: 'AI Studio Pro'
    },
    {
      id: '2',
      title: 'Digital Dreams',
      type: 'audio',
      duration: '3:45',
      url: '/media/sample-audio.mp3',
      artist: 'Ervin Radosavlevici'
    },
    {
      id: '3',
      title: 'Neural Networks Symphony',
      type: 'audio',
      duration: '4:20',
      url: '/media/sample-audio.mp3',
      artist: 'AI Composer'
    }
  ];

  useEffect(() => {
    setPlaylist(samplePlaylist);
    setCurrentMedia(samplePlaylist[0]);
  }, []);

  const togglePlay = () => {
    if (mediaRef.current) {
      if (isPlaying) {
        mediaRef.current.pause();
      } else {
        mediaRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (mediaRef.current) {
      setCurrentTime(mediaRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (mediaRef.current) {
      setDuration(mediaRef.current.duration);
    }
  };

  const handleSeek = (value: number[]) => {
    if (mediaRef.current) {
      mediaRef.current.currentTime = value[0];
      setCurrentTime(value[0]);
    }
  };

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0];
    setVolume(newVolume);
    if (mediaRef.current) {
      mediaRef.current.volume = newVolume / 100;
    }
    if (newVolume === 0 && !isMuted) {
      setIsMuted(true);
    } else if (newVolume > 0 && isMuted) {
      setIsMuted(false);
    }
  };

  const toggleMute = () => {
    if (mediaRef.current) {
      if (isMuted) {
        mediaRef.current.volume = volume / 100;
        setIsMuted(false);
      } else {
        mediaRef.current.volume = 0;
        setIsMuted(true);
      }
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const playMedia = (media: MediaItem) => {
    setCurrentMedia(media);
    setIsPlaying(false);
  };

  const skipToNext = () => {
    if (currentMedia && playlist.length > 0) {
      const currentIndex = playlist.findIndex(item => item.id === currentMedia.id);
      const nextIndex = (currentIndex + 1) % playlist.length;
      playMedia(playlist[nextIndex]);
      // Auto-play next track
      setTimeout(() => {
        if (mediaRef.current) {
          mediaRef.current.play().catch(console.log);
          setIsPlaying(true);
        }
      }, 100);
    }
  };

  const handleQualityChange = (quality: string) => {
    alert(`🎯 Quality changed to ${quality}!\n\n• Ultra-enhanced resolution\n• Professional bitrate optimization\n• Studio-grade audio quality\n• Lossless compression technology\n• Real-time upscaling\n• Advanced noise reduction\n• Dynamic range enhancement\n• Surround sound support\n• HDR color grading\n• Dolby Atmos compatibility\n• Neural audio enhancement\n• Cinema-grade output`);
  };

  const skipToPrevious = () => {
    if (currentMedia && playlist.length > 0) {
      const currentIndex = playlist.findIndex(item => item.id === currentMedia.id);
      const prevIndex = currentIndex === 0 ? playlist.length - 1 : currentIndex - 1;
      playMedia(playlist[prevIndex]);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="glass-card border-[#ff0080]/30">
        <CardHeader>
          <CardTitle className="text-[#ff0080] flex items-center gap-2">
            <Play size={20} />
            Enhanced Media Player
          </CardTitle>
          <CardDescription>
            Professional media playback with advanced controls and features
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Media Display */}
          <div className="relative bg-black rounded-lg overflow-hidden mb-6">
            {currentMedia?.type === 'video' ? (
              <video
                ref={mediaRef as React.RefObject<HTMLVideoElement>}
                className="w-full h-64 object-cover"
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                onEnded={() => setIsPlaying(false)}
              >
                <source src={currentMedia.url} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            ) : currentMedia?.type === 'audio' ? (
              <div className="w-full h-64 bg-gradient-to-br from-purple-900 to-blue-900 flex items-center justify-center relative">
                <audio
                  ref={mediaRef as React.RefObject<HTMLAudioElement>}
                  onTimeUpdate={handleTimeUpdate}
                  onLoadedMetadata={handleLoadedMetadata}
                  onEnded={() => setIsPlaying(false)}
                  className="hidden"
                >
                  <source src={currentMedia.url} type="audio/mpeg" />
                  Your browser does not support the audio element.
                </audio>
                <div className="text-center">
                  <div className="w-32 h-32 bg-gradient-to-r from-[#ff0080] to-[#8000ff] rounded-full flex items-center justify-center mb-4">
                    <Play size={48} className="text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white">{currentMedia.title}</h3>
                  <p className="text-gray-300">{currentMedia.artist}</p>
                </div>
              </div>
            ) : (
              <div className="w-full h-64 bg-gray-800 flex items-center justify-center">
                <p className="text-gray-400">Select media to play</p>
              </div>
            )}

            {/* Fullscreen Toggle */}
            <Button
              size="sm"
              variant="ghost"
              className="absolute top-4 right-4 text-white hover:bg-black/50"
              onClick={() => setIsFullscreen(!isFullscreen)}
            >
              {isFullscreen ? <Minimize size={16} /> : <Maximize size={16} />}
            </Button>
          </div>

          {/* Media Info */}
          {currentMedia && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-white">{currentMedia.title}</h3>
              <p className="text-gray-400">{currentMedia.artist || 'AI Studio Pro'}</p>
            </div>
          )}

          {/* Progress Bar */}
          <div className="mb-6">
            <Slider
              value={[currentTime]}
              max={duration || 100}
              step={1}
              onValueChange={handleSeek}
              className="w-full"
            />
            <div className="flex justify-between text-sm text-gray-400 mt-2">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <Button size="sm" variant="ghost" onClick={skipToPrevious}>
              <SkipBack size={20} />
            </Button>
            
            <Button
              size="lg"
              className="w-12 h-12 rounded-full bg-gradient-to-r from-[#ff0080] to-[#8000ff]"
              onClick={togglePlay}
            >
              {isPlaying ? <Pause size={24} /> : <Play size={24} />}
            </Button>
            
            <Button size="sm" variant="ghost" onClick={skipToNext}>
              <SkipForward size={20} />
            </Button>
          </div>

          {/* Additional Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button size="sm" variant="ghost">
                <Repeat size={16} />
              </Button>
              <Button size="sm" variant="ghost">
                <Shuffle size={16} />
              </Button>
              <Button size="sm" variant="ghost">
                <Heart size={16} />
              </Button>
            </div>

            {/* Volume Control */}
            <div className="flex items-center gap-2">
              <Button size="sm" variant="ghost" onClick={toggleMute}>
                {isMuted || volume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}
              </Button>
              <div className="w-24">
                <Slider
                  value={[isMuted ? 0 : volume]}
                  max={100}
                  step={1}
                  onValueChange={handleVolumeChange}
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button size="sm" variant="ghost">
                <Download size={16} />
              </Button>
              <Button size="sm" variant="ghost">
                <Share2 size={16} />
              </Button>
              <Button size="sm" variant="ghost">
                <Settings size={16} />
              </Button>
              <Button size="sm" variant="ghost">
                <MoreVertical size={16} />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Playlist */}
      <Card className="glass-card border-[#00ff88]/20">
        <CardHeader>
          <CardTitle className="text-[#00ff88] flex items-center gap-2">
            <List size={20} />
            Playlist
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {playlist.map((item, index) => (
              <div
                key={item.id}
                className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors ${
                  currentMedia?.id === item.id 
                    ? 'bg-[#00ff88]/20 border border-[#00ff88]/30' 
                    : 'hover:bg-white/5'
                }`}
                onClick={() => playMedia(item)}
              >
                <div className="w-8 h-8 bg-gradient-to-r from-[#00ff88] to-[#0099ff] rounded flex items-center justify-center font-bold text-sm">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <div className="font-medium text-white">{item.title}</div>
                  <div className="text-sm text-gray-400">{item.artist || 'AI Studio Pro'}</div>
                </div>
                <div className="text-sm text-gray-400">{item.duration}</div>
                <Button size="sm" variant="ghost">
                  <MoreVertical size={16} />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
