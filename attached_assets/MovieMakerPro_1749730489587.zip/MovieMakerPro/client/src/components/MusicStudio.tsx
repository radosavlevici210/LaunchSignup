import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Music, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";

export default function MusicStudio() {
  const [description, setDescription] = useState("");
  const [tempo, setTempo] = useState([120]);
  const [energy, setEnergy] = useState([7]);
  const { toast } = useToast();

  const generateMusicMutation = useMutation({
    mutationFn: async (data: { description: string; tempo: number; energy: number }) => {
      const response = await apiRequest("POST", "/api/generate-music", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Music Generated Successfully!",
        description: "Your AI-generated track is ready for review.",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!description.trim()) {
      toast({
        title: "Description Required",
        description: "Please describe your music style and mood.",
        variant: "destructive",
      });
      return;
    }
    generateMusicMutation.mutate({ 
      description, 
      tempo: tempo[0], 
      energy: energy[0] 
    });
  };

  return (
    <div className="glass-card rounded-3xl p-8 hover:scale-105 transition-all duration-300 hover:shadow-2xl hover:shadow-[#0099ff]/30">
      <div className="flex items-center mb-6">
        <Music className="text-5xl text-[#ffaa00] mr-6" size={48} />
        <h2 className="text-3xl font-bold">AI Music Studio</h2>
      </div>
      
      {/* High-end music recording studio */}
      <img 
        src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=400" 
        alt="Professional music recording studio" 
        className="w-full h-48 object-cover rounded-xl mb-6" 
      />
      
      <div className="space-y-4">
        <div>
          <label className="block text-[#ffaa00] font-semibold mb-2">Music Description</label>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-4 bg-black/40 border-2 border-white/10 rounded-xl text-white focus:border-[#ffaa00] focus:scale-105 transition-all duration-300 resize-none"
            rows={4}
            placeholder="Describe your music style and mood..."
          />
        </div>
        
        {/* Music Controls */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-gray-300 mb-2">Tempo</label>
            <Slider
              value={tempo}
              onValueChange={setTempo}
              max={200}
              min={60}
              step={1}
              className="w-full"
            />
            <div className="text-center text-sm text-[#ffaa00] mt-1">{tempo[0]} BPM</div>
          </div>
          <div>
            <label className="block text-sm text-gray-300 mb-2">Energy</label>
            <Slider
              value={energy}
              onValueChange={setEnergy}
              max={10}
              min={1}
              step={1}
              className="w-full"
            />
            <div className="text-center text-sm text-[#ffaa00] mt-1">{energy[0]}/10</div>
          </div>
        </div>
        
        {/* Audio Visualization */}
        <div className="bg-black/50 rounded-xl p-4">
          <div className="flex items-center justify-center space-x-1 h-16">
            {Array.from({ length: 32 }, (_, i) => (
              <div
                key={i}
                className="bg-gradient-to-t from-[#ffaa00] to-[#0099ff] w-2 rounded-full animate-pulse"
                style={{
                  height: `${Math.random() * 40 + 10}px`,
                  animationDelay: `${i * 0.1}s`,
                }}
              />
            ))}
          </div>
        </div>
        
        <Button
          onClick={handleGenerate}
          disabled={generateMusicMutation.isPending}
          className="w-full bg-gradient-to-r from-[#ffaa00] to-red-500 hover:scale-105 transition-all duration-300 py-4 rounded-2xl font-bold text-lg h-auto"
        >
          {generateMusicMutation.isPending ? (
            "⚡ Processing..."
          ) : (
            <>
              <Music className="mr-2" size={20} />
              🎵 Create Track
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
