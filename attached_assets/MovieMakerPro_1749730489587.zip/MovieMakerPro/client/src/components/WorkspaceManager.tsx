import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Folder, Film, Music, Video, Brain, Users, Clock, Star } from "lucide-react";

interface WorkspaceManagerProps {
  onCreateProject: (type: string, title: string) => void;
}

export default function WorkspaceManager({ onCreateProject }: WorkspaceManagerProps) {
  const [newProjectTitle, setNewProjectTitle] = useState("");
  const [selectedType, setSelectedType] = useState("movie");

  const recentProjects = [
    { id: 1, title: "Sci-Fi Epic Trailer", type: "movie", status: "in-progress", lastModified: "2 hours ago" },
    { id: 2, title: "Ambient Soundscape", type: "music", status: "completed", lastModified: "1 day ago" },
    { id: 3, title: "Product Demo Video", type: "video", status: "draft", lastModified: "3 days ago" },
    { id: 4, title: "Documentary Series", type: "movie", status: "in-progress", lastModified: "1 week ago" },
  ];

  const handleCreateProject = () => {
    if (newProjectTitle.trim() && selectedType) {
      onCreateProject(selectedType, newProjectTitle.trim());
      setNewProjectTitle("");
    }
  };

  const getProjectIcon = (type: string) => {
    switch (type) {
      case "movie": return <Film className="w-4 h-4" />;
      case "music": return <Music className="w-4 h-4" />;
      case "video": return <Video className="w-4 h-4" />;
      default: return <Folder className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-500/20 text-green-400";
      case "in-progress": return "bg-blue-500/20 text-blue-400";
      case "draft": return "bg-gray-500/20 text-gray-400";
      default: return "bg-gray-500/20 text-gray-400";
    }
  };

  return (
    <div className="space-y-6">
      {/* Create New Project */}
      <Card className="glass-card border-[#00ff88]/30">
        <CardHeader>
          <CardTitle className="text-[#00ff88] flex items-center gap-2">
            <Plus size={20} />
            Create New Project
          </CardTitle>
          <CardDescription>Start a new AI-powered creative project</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              placeholder="Project title..."
              value={newProjectTitle}
              onChange={(e) => setNewProjectTitle(e.target.value)}
              className="glass-input"
            />
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger className="glass-input">
                <SelectValue placeholder="Project type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="movie">🎬 Movie/Script</SelectItem>
                <SelectItem value="music">🎵 Music Composition</SelectItem>
                <SelectItem value="video">🎥 Video Editing</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              onClick={handleCreateProject}
              className="bg-gradient-to-r from-[#00ff88] to-[#0099ff] hover:from-[#00cc6a] hover:to-[#0077cc] text-black font-semibold"
              disabled={!newProjectTitle.trim()}
            >
              Create Project
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Workspace Overview */}
      <Tabs defaultValue="recent" className="w-full">
        <TabsList className="grid w-full grid-cols-4 glass-card">
          <TabsTrigger value="recent">Recent Projects</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="collaborative">Collaborative</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="recent" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {recentProjects.map((project) => (
              <Card key={project.id} className="glass-card border-white/10 hover:border-[#00ff88]/30 transition-colors cursor-pointer">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getProjectIcon(project.type)}
                      <CardTitle className="text-sm">{project.title}</CardTitle>
                    </div>
                    <Badge className={getStatusColor(project.status)}>
                      {project.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 text-xs text-gray-400">
                    <Clock size={12} />
                    {project.lastModified}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { name: "Cinematic Trailer", type: "movie", description: "Professional movie trailer template" },
              { name: "Lo-Fi Hip Hop", type: "music", description: "Chill music composition starter" },
              { name: "Product Showcase", type: "video", description: "Modern product demo template" },
              { name: "Documentary Style", type: "movie", description: "Documentary narrative structure" },
              { name: "EDM Track", type: "music", description: "Electronic dance music template" },
              { name: "Social Media Ad", type: "video", description: "Short-form advertising template" },
            ].map((template, index) => (
              <Card key={index} className="glass-card border-white/10 hover:border-[#0099ff]/30 transition-colors cursor-pointer">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    {getProjectIcon(template.type)}
                    <CardTitle className="text-sm">{template.name}</CardTitle>
                  </div>
                  <CardDescription className="text-xs">{template.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button size="sm" variant="outline" className="w-full">
                    Use Template
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="collaborative" className="space-y-4">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-[#ff0080]">
                <Users size={20} />
                Team Collaboration
              </CardTitle>
              <CardDescription>Real-time collaborative workspace features</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-semibold text-[#00ff88]">Active Collaborators</h4>
                  <div className="space-y-2">
                    {["Alex Chen", "Sarah Wilson", "Mike Rodriguez"].map((name, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm">
                        <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                        {name}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold text-[#0099ff]">Recent Activity</h4>
                  <div className="space-y-1 text-sm text-gray-400">
                    <div>Alex updated "Sci-Fi Epic Trailer"</div>
                    <div>Sarah added music track</div>
                    <div>Mike reviewed final cut</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="glass-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Brain size={16} />
                  AI Efficiency
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-[#00ff88]">97.3%</div>
                <div className="text-xs text-gray-400">Generation Success Rate</div>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Star size={16} />
                  Quality Score
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-[#0099ff]">9.2/10</div>
                <div className="text-xs text-gray-400">Average Project Rating</div>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Clock size={16} />
                  Time Saved
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-[#ff0080]">156h</div>
                <div className="text-xs text-gray-400">This Month</div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}