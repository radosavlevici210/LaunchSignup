export default function HeroSection() {
  return (
    <div className="glass-card rounded-3xl p-12 mb-12 text-center">
      <h1 className="text-6xl font-bold gradient-text mb-6 animate-glow">AI Studio Pro+</h1>
      <p className="text-2xl text-gray-300 mb-8">Professional Movie & Music Production Powered by Advanced AI</p>
      
      {/* Production Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
        <div className="glass-card rounded-xl p-6 border-2 border-[#00ff88]">
          <div className="text-4xl font-bold text-[#00ff88] mb-2">2,847</div>
          <div className="text-gray-300">Movies Created</div>
        </div>
        <div className="glass-card rounded-xl p-6 border-2 border-[#0099ff]">
          <div className="text-4xl font-bold text-[#0099ff] mb-2">15,293</div>
          <div className="text-gray-300">Tracks Produced</div>
        </div>
        <div className="glass-card rounded-xl p-6 border-2 border-[#ff0080]">
          <div className="text-4xl font-bold text-[#ff0080] mb-2">98.7%</div>
          <div className="text-gray-300">Success Rate</div>
        </div>
        <div className="glass-card rounded-xl p-6 border-2 border-[#ffaa00]">
          <div className="text-4xl font-bold text-[#ffaa00] mb-2">4K</div>
          <div className="text-gray-300">Active Users</div>
        </div>
      </div>
    </div>
  );
}
