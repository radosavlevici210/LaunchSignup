import { useState } from "react";
import WorkspaceManager from "@/components/WorkspaceManager";
import MovieStudio from "@/components/MovieStudio";
import MusicStudio from "@/components/MusicStudio";
import VideoEditor from "@/components/VideoEditor";
import AIAnalytics from "@/components/AIAnalytics";
import ExportSystem from "@/components/ExportSystem";
import CollaborationHub from "@/components/CollaborationHub";
import EducationalHub from "@/components/EducationalHub";
import MediaPlayer from "@/components/MediaPlayer";
import RealWorldDistribution from "@/components/RealWorldDistribution";
import ProfessionalProduction from "@/components/ProfessionalProduction";
import EnhancedAnalytics from "@/components/EnhancedAnalytics";
import AdditionalFeatures from "@/components/AdditionalFeatures";

export default function Studio() {
  const [activeWorkspace, setActiveWorkspace] = useState("manager");

  const handleCreateProject = (type: string, title: string) => {
    // Navigate to appropriate workspace based on project type
    switch (type) {
      case "movie":
        setActiveWorkspace("movie");
        break;
      case "music":
        setActiveWorkspace("music");
        break;
      case "video":
        setActiveWorkspace("video");
        break;
      default:
        setActiveWorkspace("manager");
    }
  };

  const renderWorkspace = () => {
    switch (activeWorkspace) {
      case "movie":
        return <MovieStudio />;
      case "music":
        return <MusicStudio />;
      case "video":
        return <VideoEditor />;
      case "analytics":
        return <AIAnalytics />;
      case "enhanced-analytics":
        return <EnhancedAnalytics />;
      case "export":
        return <ExportSystem />;
      case "distribution":
        return <RealWorldDistribution />;
      case "professional":
        return <ProfessionalProduction />;
      case "collaboration":
        return (
          <div className="space-y-8">
            <CollaborationHub />
            <MediaPlayer />
          </div>
        );
      case "education":
        return <EducationalHub />;
      case "additional":
        return <AdditionalFeatures />;
      default:
        return <WorkspaceManager onCreateProject={handleCreateProject} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Navigation */}
      <nav className="bg-black/20 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent animate-gradient">
                🎬 AI Studio Pro - Ultimate Educational & Professional Production Suite 🎵
              </h1>
            </div>
            <div className="flex space-x-2 overflow-x-auto scrollbar-hide">
              {[
                { id: "manager", label: "Projects", icon: "🏠" },
                { id: "movie", label: "Movies", icon: "🎬" },
                { id: "music", label: "Music", icon: "🎵" },
                { id: "video", label: "Video", icon: "🎥" },
                { id: "professional", label: "Pro Tools", icon: "⚙️" },
                { id: "distribution", label: "Distribution", icon: "🌐" },
                { id: "enhanced-analytics", label: "Analytics", icon: "📊" },
                { id: "collaboration", label: "Team", icon: "👥" },
                { id: "education", label: "Education", icon: "🎓" },
                { id: "additional", label: "AI Tools", icon: "🤖" },
                { id: "export", label: "Export", icon: "📤" },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveWorkspace(item.id)}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors whitespace-nowrap ${
                    activeWorkspace === item.id
                      ? "bg-blue-600 text-white"
                      : "text-gray-300 hover:bg-gray-700 hover:text-white"
                  }`}
                >
                  <span className="mr-1">{item.icon}</span>
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {renderWorkspace()}
      </main>
    </div>
  );
}