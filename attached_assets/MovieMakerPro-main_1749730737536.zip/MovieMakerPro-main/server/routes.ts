import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { storage } from "./storage";
import { generateMovieScript, generateMusicComposition, generateProjectAnalysis } from "./services/openai";

const generateMovieSchema = z.object({
  script: z.string().min(1, "Script is required"),
  genre: z.string().min(1, "Genre is required"),
});

const generateMusicSchema = z.object({
  description: z.string().min(1, "Description is required"),
  tempo: z.number().min(60).max(200),
  energy: z.number().min(1).max(10),
});

const exportSchema = z.object({
  type: z.string().min(1, "Export type is required"),
  settings: z.object({
    videoQuality: z.string(),
    audioFormat: z.string(),
    masterVolume: z.number().min(0).max(100),
    compression: z.number().min(0).max(10),
  }),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Generate Movie Script
  app.post("/api/generate-movie", async (req, res) => {
    try {
      const data = generateMovieSchema.parse(req.body);
      
      const movieScript = await generateMovieScript({
        script: data.script,
        genre: data.genre,
      });

      // Store the project in storage (assuming user ID 1 for demo)
      const project = await storage.createProject({
        userId: 1,
        title: movieScript.title || "Generated Movie",
        type: "movie",
        description: data.script,
        content: movieScript,
        status: "completed",
      });

      res.json({
        success: true,
        project: project,
        content: movieScript,
      });
    } catch (error) {
      console.error("Movie generation error:", error);
      res.status(400).json({
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      });
    }
  });

  // Generate Music Composition
  app.post("/api/generate-music", async (req, res) => {
    try {
      const data = generateMusicSchema.parse(req.body);
      
      const musicComposition = await generateMusicComposition({
        description: data.description,
        tempo: data.tempo,
        energy: data.energy,
      });

      // Store the project in storage
      const project = await storage.createProject({
        userId: 1,
        title: musicComposition.title || "Generated Track",
        type: "music",
        description: data.description,
        content: musicComposition,
        status: "completed",
      });

      res.json({
        success: true,
        project: project,
        content: musicComposition,
      });
    } catch (error) {
      console.error("Music generation error:", error);
      res.status(400).json({
        success: false,
        error: error.message,
      });
    }
  });

  // Export Project
  app.post("/api/export", async (req, res) => {
    try {
      const data = exportSchema.parse(req.body);
      
      // Simulate export processing
      const exportResult = {
        exportId: Math.random().toString(36).substr(2, 9),
        type: data.type,
        settings: data.settings,
        status: "processing",
        estimatedTime: "2-5 minutes",
        downloadUrl: null, // Would be populated when export completes
      };

      res.json({
        success: true,
        export: exportResult,
        message: `${data.type} export started successfully`,
      });
    } catch (error) {
      console.error("Export error:", error);
      res.status(400).json({
        success: false,
        error: error.message,
      });
    }
  });

  // Get All Projects
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getAllProjects();
      res.json({
        success: true,
        projects: projects,
      });
    } catch (error) {
      console.error("Get projects error:", error);
      res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  });

  // Get Project by ID
  app.get("/api/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({
          success: false,
          error: "Project not found",
        });
      }

      // Generate AI analysis for the project
      const analysis = await generateProjectAnalysis(project.content);

      res.json({
        success: true,
        project: project,
        analysis: analysis,
      });
    } catch (error) {
      console.error("Get project error:", error);
      res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  });

  // Update Project
  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const updates = req.body;
      
      const updatedProject = await storage.updateProject(projectId, updates);
      
      if (!updatedProject) {
        return res.status(404).json({
          success: false,
          error: "Project not found",
        });
      }

      res.json({
        success: true,
        project: updatedProject,
      });
    } catch (error) {
      console.error("Update project error:", error);
      res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  });

  // Delete Project
  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const success = await storage.deleteProject(projectId);
      
      if (!success) {
        return res.status(404).json({
          success: false,
          error: "Project not found",
        });
      }

      res.json({
        success: true,
        message: "Project deleted successfully",
      });
    } catch (error) {
      console.error("Delete project error:", error);
      res.status(500).json({
        success: false,
        error: error.message,
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
