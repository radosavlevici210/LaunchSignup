
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  DollarSign, 
  Globe, 
  Calendar,
  Target,
  Zap,
  Brain,
  Star,
  Activity,
  PieChart,
  LineChart,
  Download,
  Share2
} from "lucide-react";

interface AnalyticsData {
  contentPerformance: number;
  aiLearningRate: number;
  productionStats: {
    movies: number;
    albums: number;
    animations: number;
    voiceProjects: number;
    totalHours: number;
  };
  marketAnalysis: {
    trendingGenres: string[];
    peakTimes: string[];
    audienceGrowth: number;
  };
  collaborationMetrics: {
    activeUsers: number;
    sharedProjects: number;
    comments: number;
    revisions: number;
    uptime: number;
  };
  systemHealth: {
    cpuUsage: number;
    memory: number;
    storage: number;
    network: string;
  };
}

export default function EnhancedAnalytics() {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData>({
    contentPerformance: 87.5,
    aiLearningRate: 23,
    productionStats: {
      movies: 12,
      albums: 8,
      animations: 5,
      voiceProjects: 15,
      totalHours: 128.5
    },
    marketAnalysis: {
      trendingGenres: ['Sci-Fi', 'Electronic', '3D Animation', 'Podcasts'],
      peakTimes: ['2-4 PM', '7-9 PM', 'Weekends'],
      audienceGrowth: 34
    },
    collaborationMetrics: {
      activeUsers: 1,
      sharedProjects: 3,
      comments: 47,
      revisions: 23,
      uptime: 98.5
    },
    systemHealth: {
      cpuUsage: 45,
      memory: 62,
      storage: 78,
      network: 'Optimal'
    }
  });

  const [realTimeMetrics, setRealTimeMetrics] = useState({
    processingQueue: 0,
    aiModelsActive: 4,
    cloudSyncStatus: 'Synced',
    lastUpdate: new Date()
  });

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setRealTimeMetrics(prev => ({
        ...prev,
        processingQueue: Math.floor(Math.random() * 5),
        lastUpdate: new Date()
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const revenueData = [
    { platform: 'YouTube', revenue: 15420, percentage: 45 },
    { platform: 'Spotify', revenue: 8930, percentage: 30 },
    { platform: 'Netflix', revenue: 5670, percentage: 18 },
    { platform: 'TikTok', revenue: 3210, percentage: 12 }
  ];

  const handleExportReport = () => {
    const reportData = {
      ...analyticsData,
      generatedAt: new Date().toISOString(),
      reportType: 'Complete Analytics Report'
    };
    
    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analytics_report_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    
    alert('📊 Analytics report exported successfully!');
  };

  const handleShareInsights = () => {
    alert('🔗 Analytics insights shared!\n\n• Public dashboard link generated\n• Team members notified\n• Real-time data access enabled\n• Custom visualization ready');
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="glass-card">
          <CardContent className="p-4 text-center">
            <BarChart3 className="mx-auto mb-2 text-[#00ff88]" size={24} />
            <div className="text-2xl font-bold text-[#00ff88]">{analyticsData.contentPerformance}%</div>
            <div className="text-sm text-gray-400">Content Performance</div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardContent className="p-4 text-center">
            <TrendingUp className="mx-auto mb-2 text-[#0099ff]" size={24} />
            <div className="text-2xl font-bold text-[#0099ff]">+{analyticsData.aiLearningRate}%</div>
            <div className="text-sm text-gray-400">AI Learning Rate</div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardContent className="p-4 text-center">
            <Users className="mx-auto mb-2 text-[#ff0080]" size={24} />
            <div className="text-2xl font-bold text-[#ff0080]">{analyticsData.productionStats.totalHours}h</div>
            <div className="text-sm text-gray-400">Content Created</div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardContent className="p-4 text-center">
            <DollarSign className="mx-auto mb-2 text-[#ffaa00]" size={24} />
            <div className="text-2xl font-bold text-[#ffaa00]">$45.2K</div>
            <div className="text-sm text-gray-400">Revenue Generated</div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardContent className="p-4 text-center">
            <Globe className="mx-auto mb-2 text-[#00ffff]" size={24} />
            <div className="text-2xl font-bold text-[#00ffff]">{analyticsData.collaborationMetrics.uptime}%</div>
            <div className="text-sm text-gray-400">System Uptime</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="performance" className="w-full">
        <TabsList className="grid w-full grid-cols-5 glass-card">
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="market">Market Analysis</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="collaboration">Collaboration</TabsTrigger>
          <TabsTrigger value="realtime">Real-time</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="glass-card border-[#00ff88]/20">
              <CardHeader>
                <CardTitle className="text-[#00ff88] flex items-center gap-2">
                  <Activity size={20} />
                  Production Performance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {[
                    { label: 'Movies Created', value: analyticsData.productionStats.movies, color: '#00ff88' },
                    { label: 'Albums Produced', value: analyticsData.productionStats.albums, color: '#0099ff' },
                    { label: 'Animations Made', value: analyticsData.productionStats.animations, color: '#ff0080' },
                    { label: 'Voice Projects', value: analyticsData.productionStats.voiceProjects, color: '#ffaa00' }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm">{item.label}</span>
                      <div className="flex items-center gap-3">
                        <div className="w-24 bg-gray-200 rounded-full h-2">
                          <div 
                            className="h-2 rounded-full"
                            style={{ 
                              width: `${(item.value / 20) * 100}%`,
                              backgroundColor: item.color
                            }}
                          ></div>
                        </div>
                        <span className="text-sm font-bold w-8 text-right" style={{ color: item.color }}>
                          {item.value}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 p-4 bg-white/5 rounded-lg">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-[#00ff88]">{analyticsData.productionStats.totalHours}h</div>
                    <div className="text-sm text-gray-400">Total Content Duration</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-[#0099ff]/20">
              <CardHeader>
                <CardTitle className="text-[#0099ff] flex items-center gap-2">
                  <Brain size={20} />
                  AI Performance Metrics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Learning Speed</span>
                      <span className="text-[#00ff88]">+340% improvement</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div className="bg-[#00ff88] h-3 rounded-full w-[85%]"></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Quality Enhancement</span>
                      <span className="text-[#0099ff]">+95% improvement</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div className="bg-[#0099ff] h-3 rounded-full w-[78%]"></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Style Recognition</span>
                      <span className="text-[#ff0080]">Advanced Level</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div className="bg-[#ff0080] h-3 rounded-full w-[92%]"></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">Voice Cloning</span>
                      <span className="text-[#ffaa00]">Professional</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div className="bg-[#ffaa00] h-3 rounded-full w-[88%]"></div>
                    </div>
                  </div>
                </div>

                <Badge className="w-full justify-center bg-blue-500/20 text-blue-400 mt-4">
                  Next Learning Phase: 1.2 hours
                </Badge>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="market" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="glass-card border-[#ff0080]/20">
              <CardHeader>
                <CardTitle className="text-[#ff0080] flex items-center gap-2">
                  <Target size={20} />
                  Market Trends
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-3 text-[#ff0080]">Trending Content Types</h4>
                  <div className="space-y-2">
                    {analyticsData.marketAnalysis.trendingGenres.map((genre, index) => {
                      const trends = ['↗ +15%', '↗ +12%', '↗ +8%', '↗ +18%'];
                      const colors = ['text-green-400', 'text-blue-400', 'text-yellow-400', 'text-purple-400'];
                      return (
                        <div key={index} className="flex items-center justify-between p-2 bg-white/5 rounded">
                          <span>{genre}</span>
                          <Badge className={`${colors[index]} bg-transparent`}>
                            {trends[index]}
                          </Badge>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3 text-[#ff0080]">Peak Engagement Times</h4>
                  <div className="grid grid-cols-3 gap-2">
                    {analyticsData.marketAnalysis.peakTimes.map((time, index) => (
                      <Badge key={index} className="bg-pink-500/20 text-pink-400 justify-center">
                        {time}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="text-center p-4 bg-gradient-to-r from-pink-500/10 to-purple-500/10 rounded-lg">
                  <div className="text-2xl font-bold text-[#ff0080]">+{analyticsData.marketAnalysis.audienceGrowth}%</div>
                  <div className="text-sm text-gray-400">Audience Growth This Month</div>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-[#ffaa00]/20">
              <CardHeader>
                <CardTitle className="text-[#ffaa00] flex items-center gap-2">
                  <PieChart size={20} />
                  Content Distribution
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {[
                    { type: 'Movies', percentage: 35, color: '#00ff88' },
                    { type: 'Music Albums', percentage: 28, color: '#0099ff' },
                    { type: 'Voice Projects', percentage: 22, color: '#ff0080' },
                    { type: 'Animations', percentage: 15, color: '#ffaa00' }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm">{item.type}</span>
                      <div className="flex items-center gap-3">
                        <div className="w-20 bg-gray-200 rounded-full h-2">
                          <div 
                            className="h-2 rounded-full"
                            style={{ 
                              width: `${item.percentage}%`,
                              backgroundColor: item.color
                            }}
                          ></div>
                        </div>
                        <span className="text-sm font-bold w-8 text-right" style={{ color: item.color }}>
                          {item.percentage}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6">
                  <h4 className="font-semibold mb-3 text-[#ffaa00]">Recommendations</h4>
                  <div className="space-y-2 text-sm">
                    <div className="p-2 bg-green-500/10 rounded text-green-400">
                      ✓ Focus on Sci-Fi content (trending +15%)
                    </div>
                    <div className="p-2 bg-blue-500/10 rounded text-blue-400">
                      ✓ Increase electronic music production
                    </div>
                    <div className="p-2 bg-yellow-500/10 rounded text-yellow-400">
                      ✓ Weekend release schedule optimal
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="revenue" className="space-y-6">
          <Card className="glass-card border-[#00ff88]/20">
            <CardHeader>
              <CardTitle className="text-[#00ff88] flex items-center gap-2">
                <DollarSign size={20} />
                Revenue Analytics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-[#00ff88]">Revenue by Platform</h4>
                  {revenueData.map((platform, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Globe size={20} className="text-[#00ff88]" />
                        <span>{platform.platform}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="w-32 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-[#00ff88] h-2 rounded-full"
                            style={{ width: `${platform.percentage}%` }}
                          ></div>
                        </div>
                        <span className="text-[#00ff88] font-medium w-20 text-right">
                          ${platform.revenue.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-[#00ff88]">Revenue Projections</h4>
                  <div className="space-y-3">
                    <div className="p-3 bg-green-500/10 rounded-lg">
                      <div className="text-sm text-gray-400">This Month</div>
                      <div className="text-xl font-bold text-green-400">$12,450</div>
                    </div>
                    <div className="p-3 bg-blue-500/10 rounded-lg">
                      <div className="text-sm text-gray-400">Next Month (Projected)</div>
                      <div className="text-xl font-bold text-blue-400">$18,200</div>
                    </div>
                    <div className="p-3 bg-purple-500/10 rounded-lg">
                      <div className="text-sm text-gray-400">Annual Projection</div>
                      <div className="text-xl font-bold text-purple-400">$186,500</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="collaboration" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="glass-card border-[#00ffff]/20">
              <CardHeader>
                <CardTitle className="text-[#00ffff] flex items-center gap-2">
                  <Users size={20} />
                  Team Collaboration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-[#00ff88]">{analyticsData.collaborationMetrics.activeUsers}</div>
                    <div className="text-sm text-gray-400">Active Users</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-[#0099ff]">{analyticsData.collaborationMetrics.sharedProjects}</div>
                    <div className="text-sm text-gray-400">Shared Projects</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-[#ff0080]">{analyticsData.collaborationMetrics.comments}</div>
                    <div className="text-sm text-gray-400">Comments</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-[#ffaa00]">{analyticsData.collaborationMetrics.revisions}</div>
                    <div className="text-sm text-gray-400">Revisions</div>
                  </div>
                </div>

                <div className="text-center p-4 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-lg">
                  <div className="text-2xl font-bold text-[#00ffff]">{analyticsData.collaborationMetrics.uptime}%</div>
                  <div className="text-sm text-gray-400">System Uptime</div>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-[#32cd32]/20">
              <CardHeader>
                <CardTitle className="text-[#32cd32] flex items-center gap-2">
                  <Activity size={20} />
                  System Health
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">CPU Usage</span>
                    <span className="text-[#00ff88]">{analyticsData.systemHealth.cpuUsage}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-[#00ff88] h-2 rounded-full"
                      style={{ width: `${analyticsData.systemHealth.cpuUsage}%` }}
                    ></div>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm">Memory Usage</span>
                    <span className="text-[#0099ff]">{analyticsData.systemHealth.memory}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-[#0099ff] h-2 rounded-full"
                      style={{ width: `${analyticsData.systemHealth.memory}%` }}
                    ></div>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm">Storage Usage</span>
                    <span className="text-[#ff0080]">{analyticsData.systemHealth.storage}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-[#ff0080] h-2 rounded-full"
                      style={{ width: `${analyticsData.systemHealth.storage}%` }}
                    ></div>
                  </div>
                </div>

                <Badge className="w-full justify-center bg-green-500/20 text-green-400">
                  Network: {analyticsData.systemHealth.network}
                </Badge>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="realtime" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card className="glass-card border-[#ff6b6b]/20">
              <CardHeader>
                <CardTitle className="text-[#ff6b6b] flex items-center gap-2">
                  <Zap size={20} />
                  Processing Queue
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-3xl font-bold text-[#ff6b6b]">{realTimeMetrics.processingQueue}</div>
                  <div className="text-sm text-gray-400">Items in Queue</div>
                  <Badge className="mt-2 bg-blue-500/20 text-blue-400">
                    Est. Time: {realTimeMetrics.processingQueue * 15} min
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-[#4ecdc4]/20">
              <CardHeader>
                <CardTitle className="text-[#4ecdc4] flex items-center gap-2">
                  <Brain size={20} />
                  AI Models
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-3xl font-bold text-[#4ecdc4]">{realTimeMetrics.aiModelsActive}</div>
                  <div className="text-sm text-gray-400">Active Models</div>
                  <div className="mt-2 text-xs space-y-1">
                    <div className="flex justify-between">
                      <span>🟢 Video AI</span>
                      <span>Active</span>
                    </div>
                    <div className="flex justify-between">
                      <span>🟢 Audio AI</span>
                      <span>Active</span>
                    </div>
                    <div className="flex justify-between">
                      <span>🟢 Voice AI</span>
                      <span>Active</span>
                    </div>
                    <div className="flex justify-between">
                      <span>🟢 Text AI</span>
                      <span>Active</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-[#45b7d1]/20">
              <CardHeader>
                <CardTitle className="text-[#45b7d1] flex items-center gap-2">
                  <Globe size={20} />
                  Cloud Sync
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <Badge className="bg-green-500/20 text-green-400 text-lg mb-2">
                    {realTimeMetrics.cloudSyncStatus}
                  </Badge>
                  <div className="text-sm text-gray-400">
                    Last sync: {realTimeMetrics.lastUpdate.toLocaleTimeString()}
                  </div>
                  <div className="mt-2 space-y-1 text-xs">
                    <div>✓ Projects synchronized</div>
                    <div>✓ Settings backed up</div>
                    <div>✓ Media files uploaded</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="glass-card border-[#ffd700]/20">
            <CardHeader>
              <CardTitle className="text-[#ffd700] flex items-center gap-2">
                <LineChart size={20} />
                Live Performance Monitor
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-green-500/10 rounded-lg">
                  <div className="text-xl font-bold text-green-400">99.7%</div>
                  <div className="text-sm text-gray-400">Uptime</div>
                </div>
                <div className="text-center p-4 bg-blue-500/10 rounded-lg">
                  <div className="text-xl font-bold text-blue-400">2.3s</div>
                  <div className="text-sm text-gray-400">Avg Response</div>
                </div>
                <div className="text-center p-4 bg-purple-500/10 rounded-lg">
                  <div className="text-xl font-bold text-purple-400">156</div>
                  <div className="text-sm text-gray-400">Active Sessions</div>
                </div>
                <div className="text-center p-4 bg-orange-500/10 rounded-lg">
                  <div className="text-xl font-bold text-orange-400">12GB</div>
                  <div className="text-sm text-gray-400">Data Processed</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Action Buttons */}
      <div className="flex gap-4 justify-center">
        <Button 
          className="bg-gradient-to-r from-[#00ff88] to-[#0099ff] hover:from-[#00cc6a] hover:to-[#0077cc]"
          onClick={handleExportReport}
        >
          <Download size={16} className="mr-2" />
          Export Full Report
        </Button>
        <Button 
          className="bg-gradient-to-r from-[#ff0080] to-[#8000ff] hover:from-[#cc0066] hover:to-[#6600cc]"
          onClick={handleShareInsights}
        >
          <Share2 size={16} className="mr-2" />
          Share Insights
        </Button>
      </div>
    </div>
  );
}
