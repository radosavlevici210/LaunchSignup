import { Brain, Users } from "lucide-react";

export default function AIAnalytics() {
  const teamMembers = [
    { name: "Sarah Johnson", role: "Director", status: "online" },
    { name: "Mike Chen", role: "Sound Engineer", status: "online" },
  ];

  const activities = [
    { action: "Script updated by Sarah", color: "#00ff88" },
    { action: "Audio track added by Mike", color: "#0099ff" },
  ];

  return (
    <div className="grid lg:grid-cols-2 gap-8 mb-12">
      {/* AI Processing Center */}
      <div className="glass-card rounded-3xl p-8">
        <div className="flex items-center mb-6">
          <Brain className="text-5xl text-[#00ff88] mr-6" size={48} />
          <h2 className="text-3xl font-bold">AI Processing</h2>
        </div>
        
        {/* Futuristic AI technology concept */}
        <img 
          src="https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=300" 
          alt="AI technology neural networks" 
          className="w-full h-40 object-cover rounded-xl mb-6" 
        />
        
        {/* AI Learning Progress */}
        <div className="glass-card p-6 rounded-xl border-2 border-[#00ff88]/30 mb-4">
          <div className="flex justify-between items-center mb-3">
            <span className="text-[#00ff88] font-semibold">AI Learning Progress</span>
            <span className="text-sm text-gray-400">87%</span>
          </div>
          <div className="w-full h-3 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-[#00ff88] via-[#0099ff] to-[#ff0080] rounded-full animate-learning-pulse"></div>
          </div>
        </div>
        
        {/* Processing Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-[#0099ff]">2.4s</div>
            <div className="text-sm text-gray-400">Avg. Process Time</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-[#ffaa00]">99.2%</div>
            <div className="text-sm text-gray-400">Accuracy Rate</div>
          </div>
        </div>
      </div>
      
      {/* Collaboration Hub */}
      <div className="glass-card rounded-3xl p-8">
        <div className="flex items-center mb-6">
          <Users className="text-5xl text-[#0099ff] mr-6" size={48} />
          <h2 className="text-3xl font-bold">Team Collaboration</h2>
        </div>
        
        {/* Team collaboration workspace */}
        <img 
          src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=300" 
          alt="Creative team collaboration" 
          className="w-full h-40 object-cover rounded-xl mb-6" 
        />
        
        {/* Active Team Members */}
        <div className="space-y-3 mb-6">
          {teamMembers.map((member, index) => (
            <div key={index} className="flex items-center space-x-3">
              <div className={`w-10 h-10 ${index === 0 ? 'bg-gradient-to-r from-[#00ff88] to-[#0099ff]' : 'bg-gradient-to-r from-[#ff0080] to-purple-600'} rounded-full flex items-center justify-center`}>
                <Users size={16} />
              </div>
              <div>
                <div className="font-semibold">{member.name}</div>
                <div className="text-sm text-gray-400">{member.role} • Online</div>
              </div>
              <div className="ml-auto w-3 h-3 bg-[#00ff88] rounded-full animate-pulse"></div>
            </div>
          ))}
        </div>
        
        {/* Real-time Activity */}
        <div className="glass-card p-4 rounded-xl">
          <div className="text-sm text-gray-400 mb-2">Recent Activity</div>
          <div className="space-y-2 text-sm">
            {activities.map((activity, index) => (
              <div key={index} className="flex items-center">
                <div 
                  className="w-2 h-2 rounded-full mr-2" 
                  style={{ backgroundColor: activity.color }}
                ></div>
                <span>{activity.action}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
