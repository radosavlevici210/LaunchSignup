
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { 
  Users,
  MessageSquare,
  Video,
  Share2,
  Globe,
  Crown,
  Zap,
  Clock,
  Star,
  FileText,
  Download,
  Upload,
  Eye,
  Edit3,
  CheckCircle,
  AlertCircle,
  Wifi,
  WifiOff,
  Mic,
  MicOff,
  Camera,
  CameraOff,
  ScreenShare,
  Settings
} from "lucide-react";

interface CollaborationSession {
  id: string;
  name: string;
  participants: number;
  status: 'active' | 'waiting' | 'recording';
  type: 'movie' | 'music' | 'general';
  duration: string;
  owner: string;
}

interface TeamMember {
  id: string;
  name: string;
  avatar: string;
  role: string;
  status: 'online' | 'offline' | 'busy';
  lastSeen: string;
  contributions: number;
}

export default function CollaborationHub() {
  const [isOnline, setIsOnline] = useState(true);
  const [activeSession, setActiveSession] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [micEnabled, setMicEnabled] = useState(false);
  const [cameraEnabled, setCameraEnabled] = useState(false);
  const [screenSharing, setScreenSharing] = useState(false);

  const collaborationSessions: CollaborationSession[] = [
    {
      id: 'session-1',
      name: 'AI Revolution Movie Project',
      participants: 5,
      status: 'active',
      type: 'movie',
      duration: '2:45:00',
      owner: 'Ervin Radosavlevici'
    },
    {
      id: 'session-2',
      name: 'Electronic Dreams Album',
      participants: 3,
      status: 'recording',
      type: 'music',
      duration: '1:22:00',
      owner: 'Music Team'
    },
    {
      id: 'session-3',
      name: 'Animation Workshop',
      participants: 8,
      status: 'waiting',
      type: 'general',
      duration: '0:00:00',
      owner: 'Animation Studio'
    }
  ];

  const teamMembers: TeamMember[] = [
    {
      id: 'member-1',
      name: 'Ervin Radosavlevici',
      avatar: 'ER',
      role: 'Project Owner',
      status: 'online',
      lastSeen: 'Now',
      contributions: 156
    },
    {
      id: 'member-2',
      name: 'Sarah Chen',
      avatar: 'SC',
      role: 'AI Specialist',
      status: 'online',
      lastSeen: '2 min ago',
      contributions: 89
    },
    {
      id: 'member-3',
      name: 'Mike Johnson',
      avatar: 'MJ',
      role: 'Music Producer',
      status: 'busy',
      lastSeen: '5 min ago',
      contributions: 124
    },
    {
      id: 'member-4',
      name: 'Anna Williams',
      avatar: 'AW',
      role: 'Video Editor',
      status: 'offline',
      lastSeen: '1 hour ago',
      contributions: 67
    },
    {
      id: 'member-5',
      name: 'David Park',
      avatar: 'DP',
      role: 'Sound Engineer',
      status: 'online',
      lastSeen: 'Now',
      contributions: 92
    }
  ];

  const handleJoinSession = (sessionId: string) => {
    setActiveSession(sessionId);
    alert(`🎬 Joining collaboration session!\n\n• Real-time video/audio chat\n• Screen sharing capabilities\n• Live project editing\n• AI-powered suggestions\n• Cloud synchronization`);
  };

  const handleStartRecording = () => {
    setIsRecording(!isRecording);
    alert(isRecording ? '⏹️ Recording stopped and saved to cloud' : '🔴 Started recording collaboration session');
  };

  const handleCreateSession = () => {
    alert('🆕 New Collaboration Session Created!\n\n• Professional workspace ready\n• Team invitation system active\n• AI tools fully configured\n• Real-time sync enabled\n• 4K recording capabilities\n• Screen sharing available\n• Cloud backup activated\n• Security protocols engaged\n• Voice translation enabled\n• Global timezone support');
  };

  const handleVirtualWorkspace = () => {
    alert('🌐 Virtual Workspace Activated!\n\n• 3D collaboration environment\n• Avatar-based interaction\n• Spatial audio enabled\n• Virtual whiteboards\n• Immersive project viewing');
  };

  const handleFileShare = () => {
    alert('📁 File sharing activated!\n\n• Drag & drop files\n• Real-time synchronization\n• Version control\n• Access permissions\n• Cloud backup');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'text-green-400 bg-green-500/20';
      case 'busy': return 'text-yellow-400 bg-yellow-500/20';
      case 'offline': return 'text-gray-400 bg-gray-500/20';
      case 'active': return 'text-green-400 bg-green-500/20';
      case 'recording': return 'text-red-400 bg-red-500/20';
      case 'waiting': return 'text-blue-400 bg-blue-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  return (
    <div className="space-y-6">
      {/* Collaboration Status Header */}
      <Card className="glass-card border-[#00ffff]/30">
        <CardHeader>
          <CardTitle className="text-[#00ffff] flex items-center gap-2">
            <Users size={20} />
            Real-Time Collaboration Hub
            <Badge className={`ml-auto ${isOnline ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
              {isOnline ? <><Wifi size={14} className="mr-1" />Online</> : <><WifiOff size={14} className="mr-1" />Offline</>}
            </Badge>
          </CardTitle>
          <CardDescription>
            Professional collaboration with real-time editing, video chat, and AI assistance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-[#00ffff]">5</div>
              <div className="text-sm text-gray-400">Active Members</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#00ff88]">3</div>
              <div className="text-sm text-gray-400">Live Sessions</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#ff0080]">12</div>
              <div className="text-sm text-gray-400">Projects</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#ffaa00]">24/7</div>
              <div className="text-sm text-gray-400">Cloud Sync</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#0099ff]">HD</div>
              <div className="text-sm text-gray-400">Video Quality</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#32cd32]">AI</div>
              <div className="text-sm text-gray-400">Assistance</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="sessions" className="w-full">
        <TabsList className="grid w-full grid-cols-5 glass-card">
          <TabsTrigger value="sessions">Live Sessions</TabsTrigger>
          <TabsTrigger value="team">Team</TabsTrigger>
          <TabsTrigger value="chat">Chat</TabsTrigger>
          <TabsTrigger value="files">Files</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="sessions" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-white">Active Collaboration Sessions</h3>
            <Button 
              className="bg-gradient-to-r from-[#00ffff] to-[#0099ff]"
              onClick={handleCreateSession}
            >
              <Video size={16} className="mr-2" />
              New Session
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {collaborationSessions.map((session) => (
              <Card key={session.id} className="glass-card border-white/10 hover:border-[#00ffff]/30 transition-colors">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between mb-2">
                    <Badge className={getStatusColor(session.status)}>
                      {session.status}
                    </Badge>
                    <div className="flex items-center gap-1 text-sm text-gray-400">
                      <Clock size={14} />
                      {session.duration}
                    </div>
                  </div>
                  <CardTitle className="text-sm">{session.name}</CardTitle>
                  <CardDescription className="text-xs">
                    {session.type.charAt(0).toUpperCase() + session.type.slice(1)} Project • {session.owner}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <Users size={14} className="text-[#00ffff]" />
                      <span>{session.participants} participants</span>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {session.type}
                    </Badge>
                  </div>

                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="flex-1 bg-gradient-to-r from-[#00ffff] to-[#0099ff]"
                      onClick={() => handleJoinSession(session.id)}
                    >
                      <Video size={14} className="mr-1" />
                      Join
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="border-white/20"
                    >
                      <Eye size={14} className="mr-1" />
                      Watch
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Live Session Controls */}
          {activeSession && (
            <Card className="glass-card border-[#ff0080]/30">
              <CardHeader>
                <CardTitle className="text-[#ff0080] flex items-center gap-2">
                  <Video size={20} />
                  Live Session Controls
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                  <Button
                    size="sm"
                    variant={micEnabled ? "default" : "outline"}
                    onClick={() => setMicEnabled(!micEnabled)}
                    className={micEnabled ? "bg-green-500" : ""}
                  >
                    {micEnabled ? <Mic size={16} /> : <MicOff size={16} />}
                  </Button>
                  <Button
                    size="sm"
                    variant={cameraEnabled ? "default" : "outline"}
                    onClick={() => setCameraEnabled(!cameraEnabled)}
                    className={cameraEnabled ? "bg-green-500" : ""}
                  >
                    {cameraEnabled ? <Camera size={16} /> : <CameraOff size={16} />}
                  </Button>
                  <Button
                    size="sm"
                    variant={screenSharing ? "default" : "outline"}
                    onClick={() => setScreenSharing(!screenSharing)}
                    className={screenSharing ? "bg-blue-500" : ""}
                  >
                    <ScreenShare size={16} />
                  </Button>
                  <Button
                    size="sm"
                    variant={isRecording ? "default" : "outline"}
                    onClick={handleStartRecording}
                    className={isRecording ? "bg-red-500" : ""}
                  >
                    {isRecording ? "⏹️" : "🔴"}
                  </Button>
                  <Button size="sm" variant="outline" onClick={handleFileShare}>
                    <Share2 size={16} />
                  </Button>
                  <Button size="sm" variant="outline">
                    <MessageSquare size={16} />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="team" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold text-white">Team Members</h3>
            <Button className="bg-gradient-to-r from-[#00ff88] to-[#0099ff]">
              <Users size={16} className="mr-2" />
              Invite Member
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {teamMembers.map((member) => (
              <Card key={member.id} className="glass-card border-white/10 hover:border-[#00ff88]/30 transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="relative">
                      <div className="w-12 h-12 bg-gradient-to-r from-[#00ff88] to-[#0099ff] rounded-full flex items-center justify-center font-bold">
                        {member.avatar}
                      </div>
                      <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-gray-800 ${
                        member.status === 'online' ? 'bg-green-500' :
                        member.status === 'busy' ? 'bg-yellow-500' : 'bg-gray-500'
                      }`}></div>
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-white">{member.name}</div>
                      <div className="text-sm text-gray-400">{member.role}</div>
                    </div>
                    {member.role === 'Project Owner' && (
                      <Crown size={16} className="text-yellow-400" />
                    )}
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Status:</span>
                      <Badge className={getStatusColor(member.status)}>
                        {member.status}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Last seen:</span>
                      <span className="text-white">{member.lastSeen}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Contributions:</span>
                      <span className="text-[#00ff88] font-medium">{member.contributions}</span>
                    </div>
                  </div>

                  <div className="flex gap-2 mt-3">
                    <Button size="sm" className="flex-1">
                      <MessageSquare size={14} className="mr-1" />
                      Chat
                    </Button>
                    <Button size="sm" variant="outline">
                      <Video size={14} />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="chat" className="space-y-6">
          <Card className="glass-card border-[#ffaa00]/20">
            <CardHeader>
              <CardTitle className="text-[#ffaa00] flex items-center gap-2">
                <MessageSquare size={20} />
                Team Chat
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-96 bg-black/20 rounded-lg p-4 mb-4 overflow-y-auto">
                <div className="space-y-4">
                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-gradient-to-r from-[#00ff88] to-[#0099ff] rounded-full flex items-center justify-center text-xs font-bold">
                      ER
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-gray-400">Ervin Radosavlevici • 2:30 PM</div>
                      <div className="text-white">Great progress on the AI Revolution project! The new voice synthesis is incredible.</div>
                    </div>
                  </div>
                  
                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-gradient-to-r from-[#ff0080] to-[#8000ff] rounded-full flex items-center justify-center text-xs font-bold">
                      SC
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-gray-400">Sarah Chen • 2:32 PM</div>
                      <div className="text-white">Thanks! The AI model is learning so fast. Quality improved by 15% today.</div>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-gradient-to-r from-[#ffaa00] to-[#ff6b6b] rounded-full flex items-center justify-center text-xs font-bold">
                      MJ
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-gray-400">Mike Johnson • 2:35 PM</div>
                      <div className="text-white">Music tracks are ready for review. Can we schedule a listening session?</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <Input 
                  placeholder="Type your message..." 
                  className="flex-1 glass-input"
                />
                <Button className="bg-gradient-to-r from-[#00ff88] to-[#0099ff]">
                  Send
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="files" className="space-y-6">
          <Card className="glass-card border-[#32cd32]/20">
            <CardHeader>
              <CardTitle className="text-[#32cd32] flex items-center gap-2">
                <FileText size={20} />
                Shared Files & Resources
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="border-2 border-dashed border-gray-600 rounded-lg p-8 text-center hover:border-[#00ff88] transition-colors cursor-pointer">
                  <Upload size={48} className="mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-400">Drag & drop files here or click to browse</p>
                  <p className="text-sm text-gray-500 mt-2">Supports all media formats</p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText size={20} className="text-[#00ff88]" />
                      <div>
                        <div className="font-medium">AI_Revolution_Script.docx</div>
                        <div className="text-sm text-gray-400">Updated 2 hours ago</div>
                      </div>
                    </div>
                    <Button size="sm" variant="outline">
                      <Download size={14} />
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText size={20} className="text-[#0099ff]" />
                      <div>
                        <div className="font-medium">Background_Music.mp3</div>
                        <div className="text-sm text-gray-400">Updated 5 hours ago</div>
                      </div>
                    </div>
                    <Button size="sm" variant="outline">
                      <Download size={14} />
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText size={20} className="text-[#ff0080]" />
                      <div>
                        <div className="font-medium">Character_Designs.psd</div>
                        <div className="text-sm text-gray-400">Updated 1 day ago</div>
                      </div>
                    </div>
                    <Button size="sm" variant="outline">
                      <Download size={14} />
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <Button className="bg-gradient-to-r from-[#32cd32] to-[#228b22]">
                  <Upload size={16} className="mr-2" />
                  Upload Files
                </Button>
                <Button variant="outline">
                  <Globe size={16} className="mr-2" />
                  Cloud Storage
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card className="glass-card border-[#8000ff]/20">
            <CardHeader>
              <CardTitle className="text-[#8000ff] flex items-center gap-2">
                <Settings size={20} />
                Collaboration Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">Auto-save collaborations</div>
                    <div className="text-sm text-gray-400">Automatically save project changes</div>
                  </div>
                  <Button size="sm" className="bg-green-500">ON</Button>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">Real-time notifications</div>
                    <div className="text-sm text-gray-400">Get notified of team activities</div>
                  </div>
                  <Button size="sm" className="bg-green-500">ON</Button>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">HD video quality</div>
                    <div className="text-sm text-gray-400">Use high-definition video for calls</div>
                  </div>
                  <Button size="sm" className="bg-green-500">ON</Button>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">AI assistance</div>
                    <div className="text-sm text-gray-400">Enable AI-powered suggestions</div>
                  </div>
                  <Button size="sm" className="bg-green-500">ON</Button>
                </div>
              </div>

              <div className="pt-4 border-t border-white/10">
                <h4 className="font-medium mb-4">Access Permissions</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>Project Owner</span>
                    <Badge className="bg-yellow-500/20 text-yellow-400">Full Access</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Team Members</span>
                    <Badge className="bg-blue-500/20 text-blue-400">Edit Access</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Guests</span>
                    <Badge className="bg-gray-500/20 text-gray-400">View Only</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
