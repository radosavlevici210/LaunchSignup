import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { 
  Settings, 
  Film, 
  Music, 
  Palette, 
  Cpu, 
  HardDrive, 
  Zap,
  Brain,
  Users,
  Clock,
  Star,
  BarChart3,
  Cloud,
  Shield,
  Database,
  Monitor,
  Award,
  Briefcase,
  Globe,
  Smartphone,
  Mic,
  Camera,
  Edit3,
  Layers,
  Target,
  TrendingUp,
  Calendar,
  MessageSquare,
  Bookmark,
  PlayCircle,
  PauseCircle,
  Volume2,
  FileText,
  Download,
  Share2
} from "lucide-react";

interface ProductionStats {
  moviesCreated: number;
  albumsProduced: number;
  animationsMade: number;
  voiceProjects: number;
  totalDuration: string;
  qualityScore: number;
  aiModelsUsed: number;
  collaborators: number;
}

interface AIModel {
  id: string;
  name: string;
  description: string;
  capability: string;
  status: 'active' | 'inactive' | 'loading';
  performance: number;
}

export default function ProfessionalProduction() {
  const [productionStats, setProductionStats] = useState<ProductionStats>({
    moviesCreated: 12,
    albumsProduced: 8,
    animationsMade: 5,
    voiceProjects: 23,
    totalDuration: "156:42:00",
    qualityScore: 97,
    aiModelsUsed: 12,
    collaborators: 4
  });

  const [selectedQuality, setSelectedQuality] = useState("4k");
  const [renderProgress, setRenderProgress] = useState(0);
  const [isRendering, setIsRendering] = useState(false);
  const [aiLearningLevel, setAiLearningLevel] = useState(95);

  const aiModels: AIModel[] = [
    {
      id: 'gpt-4-turbo',
      name: 'GPT-4 Turbo',
      description: 'Enhanced creativity and reasoning',
      capability: 'Text & Script Generation',
      status: 'active',
      performance: 98
    },
    {
      id: 'claude-3-opus',
      name: 'Claude-3 Opus',
      description: 'Advanced analysis and writing',
      capability: 'Content Analysis',
      status: 'active',
      performance: 96
    },
    {
      id: 'dall-e-3',
      name: 'DALL-E 3',
      description: 'Advanced image generation',
      capability: 'Visual Generation',
      status: 'active',
      performance: 94
    },
    {
      id: 'suno-ai',
      name: 'Suno AI',
      description: 'Advanced music generation',
      capability: 'Music Composition',
      status: 'active',
      performance: 92
    },
    {
      id: 'runway-gen3',
      name: 'Runway Gen-3',
      description: 'Video generation and editing',
      capability: 'Video Processing',
      status: 'active',
      performance: 90
    },
    {
      id: 'midjourney-v6',
      name: 'Midjourney V6',
      description: 'Artistic image creation',
      capability: 'Artistic Generation',
      status: 'active',
      performance: 93
    }
  ];

  const systemMetrics = {
    cpuUsage: 45,
    memoryUsage: 62,
    storageUsage: 78,
    networkStatus: 'Optimal',
    uptime: '99.7%',
    processingQueue: 3,
    activeJobs: 2
  };

  const handleRenderProject = () => {
    setIsRendering(true);
    setRenderProgress(0);

    const interval = setInterval(() => {
      setRenderProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsRendering(false);
          return 100;
        }
        return prev + 2;
      });
    }, 200);
  };

  const handleExportProject = (format: string) => {
    alert(`🎬 Exporting project in ${format} format!\n\nOptimized for:\n• Professional quality\n• Platform compatibility\n• Fast delivery\n• Maximum quality retention`);
  };

  const handleAIOptimization = () => {
    setAiLearningLevel(prev => Math.min(100, prev + Math.random() * 5));
    alert('🧠 AI Ultra Optimization Applied!\n\n• Performance increased by 650%\n• Quality enhanced by 950%\n• Processing speed improved by 1800%\n• Learning algorithms updated\n• Memory optimization complete\n• Neural network fine-tuned\n• GPU acceleration enabled\n• Quantum processing ready\n• Multi-core utilization\n• Advanced caching system\n• Real-time optimization\n• Professional-grade output\n• Machine learning acceleration\n• Tensor processing units active');
  };

  const handleCloudSync = () => {
    alert('☁️ Cloud Sync Complete!\n\n• Projects synchronized\n• Settings backed up\n• Collaboration data updated\n• Security verified\n• Real-time sync enabled');
  };

  return (
    <div className="space-y-6">
      {/* Production Overview */}
      <Card className="glass-card border-[#ffaa00]/30">
        <CardHeader>
          <CardTitle className="text-[#ffaa00] flex items-center gap-2">
            <Settings size={20} />
            Professional Production Suite
          </CardTitle>
          <CardDescription>
            Advanced tools for professional content creation with enhanced AI capabilities
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-8 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-[#00ff88]">{productionStats.moviesCreated}</div>
              <div className="text-xs text-gray-400">Movies</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#0099ff]">{productionStats.albumsProduced}</div>
              <div className="text-xs text-gray-400">Albums</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#ff0080]">{productionStats.animationsMade}</div>
              <div className="text-xs text-gray-400">Animations</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#ffaa00]">{productionStats.voiceProjects}</div>
              <div className="text-xs text-gray-400">Voice</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-[#00ffff]">{productionStats.totalDuration}</div>
              <div className="text-xs text-gray-400">Total Duration</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#32cd32]">{productionStats.qualityScore}%</div>
              <div className="text-xs text-gray-400">Quality</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#ff6b6b]">{productionStats.aiModelsUsed}</div>
              <div className="text-xs text-gray-400">AI Models</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#dda0dd]">{productionStats.collaborators}</div>
              <div className="text-xs text-gray-400">Team</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="production" className="w-full">
        <TabsList className="grid w-full grid-cols-6 glass-card">
          <TabsTrigger value="production">Production</TabsTrigger>
          <TabsTrigger value="ai-models">AI Models</TabsTrigger>
          <TabsTrigger value="optimization">Optimization</TabsTrigger>
          <TabsTrigger value="export">Export</TabsTrigger>
          <TabsTrigger value="cloud">Cloud</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="production" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="glass-card border-[#ff0080]/20">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-4">
                  <Film className="w-6 h-6 text-[#ff0080]" />
                  <h4 className="font-semibold">Movie Production</h4>
                </div>
                <div className="space-y-3">
                  <Select>
                    <SelectTrigger className="glass-input">
                      <SelectValue placeholder="Select AI Model" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cinematic-pro">Cinematic Pro (Hollywood)</SelectItem>
                      <SelectItem value="indie-master">Indie Master (Creative)</SelectItem>
                      <SelectItem value="documentary-ai">Documentary AI</SelectItem>
                      <SelectItem value="quantum-cinema">Quantum Cinema</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={selectedQuality} onValueChange={setSelectedQuality}>
                    <SelectTrigger className="glass-input">
                      <SelectValue placeholder="Production Quality" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="8k">8K Ultra HD (Cinema)</SelectItem>
                      <SelectItem value="4k">4K Ultra HD</SelectItem>
                      <SelectItem value="1080p">1080p Full HD</SelectItem>
                      <SelectItem value="imax">IMAX Quality</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button 
                    className="w-full bg-gradient-to-r from-[#ff0080] to-[#8000ff]"
                    onClick={handleRenderProject}
                    disabled={isRendering}
                  >
                    {isRendering ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Rendering... {renderProgress}%
                      </>
                    ) : (
                      <>
                        <Film size={16} className="mr-2" />
                        Start Production
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-[#00ff88]/20">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-4">
                  <Music className="w-6 h-6 text-[#00ff88]" />
                  <h4 className="font-semibold">Music Production</h4>
                </div>
                <div className="space-y-3">
                  <Select>
                    <SelectTrigger className="glass-input">
                      <SelectValue placeholder="Select Music AI" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="composer-pro">Composer Pro (Billboard)</SelectItem>
                      <SelectItem value="jazz-master">Jazz Master</SelectItem>
                      <SelectItem value="electronic-genius">Electronic Genius</SelectItem>
                      <SelectItem value="orchestral-ai">Orchestral AI</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select>
                    <SelectTrigger className="glass-input">
                      <SelectValue placeholder="Audio Quality" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="studio">Studio Quality (24-bit)</SelectItem>
                      <SelectItem value="radio">Radio Ready</SelectItem>
                      <SelectItem value="streaming">Streaming Optimized</SelectItem>
                      <SelectItem value="vinyl">Vinyl Master</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button className="w-full bg-gradient-to-r from-[#00ff88] to-[#0099ff]">
                    <Music size={16} className="mr-2" />
                    Generate Music
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {isRendering && (
            <Card className="glass-card border-[#ffaa00]/20">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-4">
                  <Zap className="w-6 h-6 text-[#ffaa00]" />
                  <h4 className="font-semibold">Real-time Production Progress</h4>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Processing Scene 3 of 12</span>
                    <span>{renderProgress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div 
                      className="bg-gradient-to-r from-[#00ff88] to-[#0099ff] h-3 rounded-full transition-all duration-500"
                      style={{ width: `${renderProgress}%` }}
                    ></div>
                  </div>
                  <div className="text-xs text-gray-400">
                    Estimated time remaining: {Math.max(0, 10 - Math.floor(renderProgress / 10))} minutes
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="ai-models" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {aiModels.map((model) => (
              <Card key={model.id} className="glass-card border-white/10 hover:border-[#00ff88]/30 transition-colors">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm">{model.name}</CardTitle>
                    <Badge 
                      className={
                        model.status === 'active' ? 'bg-green-500/20 text-green-400' :
                        model.status === 'loading' ? 'bg-blue-500/20 text-blue-400' :
                        'bg-gray-500/20 text-gray-400'
                      }
                    >
                      {model.status}
                    </Badge>
                  </div>
                  <CardDescription className="text-xs">
                    {model.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-xs">
                    <span className="text-[#00ff88]">Capability:</span> {model.capability}
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span>Performance</span>
                      <span>{model.performance}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-[#00ff88] h-2 rounded-full"
                        style={{ width: `${model.performance}%` }}
                      ></div>
                    </div>
                  </div>
                  <Button size="sm" className="w-full">
                    Configure Model
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="glass-card border-[#0099ff]/20">
            <CardHeader>
              <CardTitle className="text-[#0099ff] flex items-center gap-2">
                <Brain size={20} />
                AI Learning Progress
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Overall AI Intelligence Level</span>
                  <span className="text-[#00ff88]">{aiLearningLevel}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-[#00ff88] to-[#0099ff] h-3 rounded-full transition-all duration-1000"
                    style={{ width: `${aiLearningLevel}%` }}
                  ></div>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div className="text-center">
                  <div className="text-lg font-bold text-[#00ff88]">+450%</div>
                  <div className="text-gray-400">Speed Optimization</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-[#0099ff]">+125%</div>
                  <div className="text-gray-400">Quality Enhancement</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-[#ff0080]">Master</div>
                  <div className="text-gray-400">Style Recognition</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-[#ffaa00]">Professional+</div>
                  <div className="text-gray-400">Voice Cloning</div>
                </div>
              </div>

              <Button 
                className="w-full bg-gradient-to-r from-[#ff6b6b] to-[#4ecdc4]"
                onClick={handleAIOptimization}
              >
                <Brain size={16} className="mr-2" />
                Optimize AI Performance
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="optimization" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="glass-card border-[#32cd32]/20">
              <CardHeader>
                <CardTitle className="text-[#32cd32] flex items-center gap-2">
                  <Cpu size={20} />
                  Performance Optimization
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Render Threads</span>
                    <Badge className="bg-blue-500/20 text-blue-400">8 cores</Badge>
                  </div>
                  <Slider
                    defaultValue={[8]}
                    max={16}
                    min={1}
                    step={1}
                    className="w-full"
                  />

                  <div className="flex justify-between items-center">
                    <span className="text-sm">Memory Allocation</span>
                    <Badge className="bg-green-500/20 text-green-400">16GB</Badge>
                  </div>
                  <Slider
                    defaultValue={[16]}
                    max={32}
                    min={4}
                    step={2}
                    className="w-full"
                  />

                  <div className="flex justify-between items-center">
                    <span className="text-sm">GPU Acceleration</span>
                    <Badge className="bg-purple-500/20 text-purple-400">Enabled</Badge>
                  </div>
                </div>

                <Button className="w-full bg-gradient-to-r from-[#32cd32] to-[#228b22]">
                  <Zap size={16} className="mr-2" />
                  Apply Optimization
                </Button>
              </CardContent>
            </Card>

            <Card className="glass-card border-[#ff6b6b]/20">
              <CardHeader>
                <CardTitle className="text-[#ff6b6b] flex items-center gap-2">
                  <Monitor size={20} />
                  System Monitoring
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">CPU Usage</span>
                    <span className="text-[#00ff88]">{systemMetrics.cpuUsage}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-[#00ff88] h-2 rounded-full"
                      style={{ width: `${systemMetrics.cpuUsage}%` }}
                    ></div>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm">Memory Usage</span>
                    <span className="text-[#0099ff]">{systemMetrics.memoryUsage}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-[#0099ff] h-2 rounded-full"
                      style={{ width: `${systemMetrics.memoryUsage}%` }}
                    ></div>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm">Storage Usage</span>
                    <span className="text-[#ff0080]">{systemMetrics.storageUsage}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-[#ff0080] h-2 rounded-full"
                      style={{ width: `${systemMetrics.storageUsage}%` }}
                    ></div>
                  </div>
                </div>

                <div className="text-center">
                  <div className="text-sm text-gray-400">System Uptime</div>
                  <div className="text-xl font-bold text-[#00ff88]">{systemMetrics.uptime}</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="export" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="glass-card border-[#00ff88]/20">
              <CardHeader>
                <CardTitle className="text-[#00ff88] text-center">Professional Export</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <Film size={48} className="mx-auto text-[#00ff88] mb-4" />
                  <h4 className="font-semibold mb-2">Cinema Quality</h4>
                  <p className="text-sm text-gray-400 mb-4">DCI 4K, Dolby Atmos, Festival Ready</p>
                </div>
                <Button 
                  className="w-full bg-gradient-to-r from-[#00ff88] to-[#0099ff]"
                  onClick={() => handleExportProject('Cinema Quality')}
                >
                  Export Cinema
                </Button>
              </CardContent>
            </Card>

            <Card className="glass-card border-[#0099ff]/20">
              <CardHeader>
                <CardTitle className="text-[#0099ff] text-center">Streaming Ready</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <Cloud size={48} className="mx-auto text-[#0099ff] mb-4" />
                  <h4 className="font-semibold mb-2">Multi-Platform</h4>
                  <p className="text-sm text-gray-400 mb-4">YouTube, Netflix, Amazon Prime</p>
                </div>
                <Button 
                  className="w-full bg-gradient-to-r from-[#0099ff] to-[#00ffff]"
                  onClick={() => handleExportProject('Streaming')}
                >
                  Export Streaming
                </Button>
              </CardContent>
            </Card>

            <Card className="glass-card border-[#ff0080]/20">
              <CardHeader>
                <CardTitle className="text-[#ff0080] text-center">Social Media</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <Users size={48} className="mx-auto text-[#ff0080] mb-4" />
                  <h4 className="font-semibold mb-2">Social Optimized</h4>
                  <p className="text-sm text-gray-400 mb-4">TikTok, Instagram, Twitter</p>
                </div>
                <Button 
                  className="w-full bg-gradient-to-r from-[#ff0080] to-[#8000ff]"
                  onClick={() => handleExportProject('Social Media')}
                >
                  Export Social
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="cloud" className="space-y-4">
          <Card className="glass-card border-[#00bfff]/20">
            <CardHeader>
              <CardTitle className="text-[#00bfff] flex items-center gap-2">
                <Cloud size={20} />
                Cloud Storage & Sync
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <HardDrive size={48} className="mx-auto text-[#00bfff] mb-2" />
                  <div className="text-2xl font-bold text-[#00bfff]">2.3 TB</div>
                  <div className="text-sm text-gray-400">Used</div>
                </div>
                <div className="text-center">
                  <Database size={48} className="mx-auto text-[#00ff88] mb-2" />
                  <div className="text-2xl font-bold text-[#00ff88]">7.7 TB</div>
                  <div className="text-sm text-gray-400">Available</div>
                </div>
                <div className="text-center">
                  <Zap size={48} className="mx-auto text-[#ffaa00] mb-2" />
                  <div className="text-2xl font-bold text-[#ffaa00]">Active</div>
                  <div className="text-sm text-gray-400">Sync Status</div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Storage Usage</span>
                  <span className="text-[#00bfff]">23%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div className="bg-gradient-to-r from-[#00bfff] to-[#0099ff] h-3 rounded-full w-[23%]"></div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <Badge className="bg-green-500/20 text-green-400 mb-2">Connected</Badge>
                  <div>Google Drive</div>
                </div>
                <div>
                  <Badge className="bg-green-500/20 text-green-400 mb-2">Connected</Badge>
                  <div>Dropbox</div>
                </div>
                <div>
                  <Badge className="bg-green-500/20 text-green-400 mb-2">Connected</Badge>
                  <div>OneDrive</div>
                </div>
                <div>
                  <Badge className="bg-green-500/20 text-green-400 mb-2">Connected</Badge>
                  <div>AWS S3</div>
                </div>
              </div>

              <Button className="w-full bg-gradient-to-r from-[#00bfff] to-[#0099ff]">
                <Cloud size={16} className="mr-2" />
                Manage Cloud Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-4">
          <Card className="glass-card border-[#ff6b6b]/20">
            <CardHeader>
              <CardTitle className="text-[#ff6b6b] flex items-center gap-2">
                <Shield size={20} />
                Security & Backup
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-[#ff6b6b]">Security Status</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Encryption</span>
                      <Badge className="bg-green-500/20 text-green-400">AES-256</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Backup Status</span>
                      <Badge className="bg-green-500/20 text-green-400">Active</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Access Control</span>
                      <Badge className="bg-green-500/20 text-green-400">Secured</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Audit Logging</span>
                      <Badge className="bg-green-500/20 text-green-400">Enabled</Badge>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-[#ff6b6b]">Backup Information</h4>
                  <div className="space-y-2 text-sm">
                    <div>Last Backup: <span className="text-[#00ff88]">5 minutes ago</span></div>
                    <div>Next Backup: <span className="text-[#0099ff]">55 minutes</span></div>
                    <div>Items Backed Up: <span className="text-[#ffaa00]">1,247</span></div>
                    <div>Backup Size: <span className="text-[#ff0080]">1.8 TB</span></div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button className="bg-gradient-to-r from-[#ff6b6b] to-[#ff5252]">
                  <Shield size={16} className="mr-2" />
                  Security Scan
                </Button>
                <Button className="bg-gradient-to-r from-[#4ecdc4] to-[#44a08d]">
                  <HardDrive size={16} className="mr-2" />
                  Manual Backup
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}