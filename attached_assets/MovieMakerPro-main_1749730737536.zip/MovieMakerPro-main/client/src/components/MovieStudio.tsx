import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Film, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

const genres = ["Action", "Drama", "Sci-Fi", "Comedy", "Horror", "Romance"];

export default function MovieStudio() {
  const [script, setScript] = useState("");
  const [selectedGenre, setSelectedGenre] = useState<string>("");
  const { toast } = useToast();

  const generateMovieMutation = useMutation({
    mutationFn: async (data: { script: string; genre: string }) => {
      const response = await apiRequest("POST", "/api/generate-movie", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Movie Generated Successfully!",
        description: "Your AI-generated movie is ready for review.",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!script.trim()) {
      toast({
        title: "Script Required",
        description: "Please enter a movie script or concept.",
        variant: "destructive",
      });
      return;
    }
    generateMovieMutation.mutate({ script, genre: selectedGenre });
  };

  return (
    <div className="glass-card rounded-3xl p-8 hover:scale-105 transition-all duration-300 hover:shadow-2xl hover:shadow-[#00ff88]/30">
      <div className="flex items-center mb-6">
        <Film className="text-5xl text-[#ff0080] mr-6" size={48} />
        <h2 className="text-3xl font-bold">AI Movie Studio</h2>
      </div>
      
      {/* Professional movie production studio */}
      <img 
        src="https://images.unsplash.com/photo-1518611012118-696072aa579a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=400" 
        alt="Professional movie production studio" 
        className="w-full h-48 object-cover rounded-xl mb-6" 
      />
      
      <div className="space-y-4">
        <div>
          <label className="block text-[#00ff88] font-semibold mb-2">Script Prompt</label>
          <Textarea
            value={script}
            onChange={(e) => setScript(e.target.value)}
            className="w-full p-4 bg-black/40 border-2 border-white/10 rounded-xl text-white focus:border-[#00ff88] focus:scale-105 transition-all duration-300 resize-none"
            rows={4}
            placeholder="Describe your movie concept..."
          />
        </div>
        
        {/* Genre Selection */}
        <div className="grid grid-cols-3 gap-3">
          {genres.map((genre) => (
            <div
              key={genre}
              className={`glass-card p-3 rounded-lg text-center cursor-pointer transition-all border-2 ${
                selectedGenre === genre
                  ? "bg-[#00ff88]/20 border-[#00ff88]"
                  : "border-transparent hover:bg-[#00ff88]/20 hover:border-[#00ff88]"
              }`}
              onClick={() => setSelectedGenre(genre)}
            >
              {genre}
            </div>
          ))}
        </div>
        
        {/* Timeline Visualization */}
        <div className="bg-black/50 rounded-xl p-4 relative overflow-hidden">
          <div className="h-6 bg-gradient-to-r from-[#00ff88] via-[#0099ff] to-[#ff0080] rounded-full relative">
            <div className="timeline-marker"></div>
          </div>
          <div className="text-sm text-gray-400 mt-2">Timeline: 00:00 / 02:30</div>
        </div>
        
        <Button
          onClick={handleGenerate}
          disabled={generateMovieMutation.isPending}
          className="w-full bg-gradient-to-r from-[#ff0080] to-purple-600 hover:scale-105 transition-all duration-300 py-4 rounded-2xl font-bold text-lg h-auto"
        >
          {generateMovieMutation.isPending ? (
            "⚡ Processing..."
          ) : (
            <>
              <Film className="mr-2" size={20} />
              🎬 Generate Movie
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
