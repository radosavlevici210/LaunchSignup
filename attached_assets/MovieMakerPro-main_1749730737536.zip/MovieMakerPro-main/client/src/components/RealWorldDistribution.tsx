
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Globe, 
  Upload, 
  Radio, 
  Tv, 
  Music, 
  Film, 
  Smartphone,
  DollarSign,
  TrendingUp,
  Users,
  Calendar,
  BarChart3,
  Settings,
  Zap
} from "lucide-react";

interface DistributionPlatform {
  id: string;
  name: string;
  icon: any;
  description: string;
  status: 'available' | 'processing' | 'live';
  requirements: string[];
  revenue: string;
}

export default function RealWorldDistribution() {
  const [selectedPlatform, setSelectedPlatform] = useState<string>("");
  const [distributionProgress, setDistributionProgress] = useState<{ [key: string]: number }>({});
  const [activeDistributions, setActiveDistributions] = useState<string[]>([]);

  const platforms: DistributionPlatform[] = [
    {
      id: 'youtube',
      name: 'YouTube',
      icon: Film,
      description: '8K video upload, AI thumbnails, SEO optimization',
      status: 'available',
      requirements: ['4K+ video', 'Metadata', 'Thumbnails', 'Captions'],
      revenue: '$2-5 per 1K views'
    },
    {
      id: 'spotify',
      name: 'Spotify',
      icon: Music,
      description: 'Professional mastering, playlist submission',
      status: 'available',
      requirements: ['WAV/FLAC audio', 'Album artwork', 'ISRC codes', 'Metadata'],
      revenue: '$0.003-0.005 per stream'
    },
    {
      id: 'netflix',
      name: 'Netflix/Streaming',
      icon: Tv,
      description: 'Cinema quality, professional submission',
      status: 'available',
      requirements: ['DCI 4K', 'Dolby Atmos', 'Closed captions', 'Legal clearances'],
      revenue: 'Licensing deals'
    },
    {
      id: 'radio',
      name: 'Radio Broadcasting',
      icon: Radio,
      description: 'Broadcast quality, promotion packages',
      status: 'available',
      requirements: ['Broadcast WAV', 'Radio edit', 'Promotion kit', 'Airplay tracking'],
      revenue: 'Performance royalties'
    },
    {
      id: 'tiktok',
      name: 'TikTok/Social',
      icon: Smartphone,
      description: 'Mobile optimized, trend integration',
      status: 'available',
      requirements: ['Vertical video', 'Trending sounds', 'Hashtag strategy', 'Short format'],
      revenue: 'Brand partnerships'
    },
    {
      id: 'cinema',
      name: 'Theater/Cinema',
      icon: Film,
      description: 'DCI compliance, festival submissions',
      status: 'available',
      requirements: ['DCI 4K package', '7.1 surround', 'Festival strategy', 'Distribution rights'],
      revenue: 'Box office share'
    }
  ];

  const distributionMetrics = {
    totalViews: '2.5M',
    totalRevenue: '$45,230',
    activePlatforms: 6,
    conversionRate: '12.3%',
    topPerformer: 'YouTube',
    growthRate: '+34%'
  };

  const handleDistribute = async (platformId: string, contentType: string) => {
    setDistributionProgress(prev => ({ ...prev, [platformId]: 0 }));
    setActiveDistributions(prev => [...prev, platformId]);

    // Simulate distribution process
    const interval = setInterval(() => {
      setDistributionProgress(prev => {
        const current = prev[platformId] || 0;
        if (current >= 100) {
          clearInterval(interval);
          return prev;
        }
        return { ...prev, [platformId]: current + 10 };
      });
    }, 500);

    // Complete after 5 seconds
    setTimeout(() => {
      setDistributionProgress(prev => ({ ...prev, [platformId]: 100 }));
      clearInterval(interval);
    }, 5000);
  };

  const handleMarketingCampaign = () => {
    // Simulate marketing campaign launch
    alert('🚀 Marketing Campaign Launched!\n\n• Social media campaigns activated\n• Influencer outreach initiated\n• Press releases distributed\n• Email marketing started\n• SEO optimization applied');
  };

  const handleMonetizationSetup = () => {
    // Simulate monetization setup
    alert('💰 Monetization Setup Complete!\n\n• Ad revenue streams enabled\n• Subscription models configured\n• Merchandise integration ready\n• Licensing opportunities identified\n• Revenue tracking activated');
  };

  return (
    <div className="space-y-6">
      {/* Distribution Overview */}
      <Card className="glass-card border-[#00ff88]/30">
        <CardHeader>
          <CardTitle className="text-[#00ff88] flex items-center gap-2">
            <Globe size={20} />
            Real-World Distribution Hub
          </CardTitle>
          <CardDescription>
            Professional distribution to all major platforms with real-world revenue tracking
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-[#00ff88]">{distributionMetrics.totalViews}</div>
              <div className="text-sm text-gray-400">Total Views</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#0099ff]">{distributionMetrics.totalRevenue}</div>
              <div className="text-sm text-gray-400">Revenue</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#ff0080]">{distributionMetrics.activePlatforms}</div>
              <div className="text-sm text-gray-400">Platforms</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#ffaa00]">{distributionMetrics.conversionRate}</div>
              <div className="text-sm text-gray-400">Conversion</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#00ffff]">{distributionMetrics.topPerformer}</div>
              <div className="text-sm text-gray-400">Top Platform</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#32cd32]">{distributionMetrics.growthRate}</div>
              <div className="text-sm text-gray-400">Growth</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="platforms" className="w-full">
        <TabsList className="grid w-full grid-cols-4 glass-card">
          <TabsTrigger value="platforms">Distribution Platforms</TabsTrigger>
          <TabsTrigger value="marketing">Marketing & Promotion</TabsTrigger>
          <TabsTrigger value="analytics">Revenue Analytics</TabsTrigger>
          <TabsTrigger value="automation">Automation Tools</TabsTrigger>
        </TabsList>

        <TabsContent value="platforms" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {platforms.map((platform) => {
              const Icon = platform.icon;
              const progress = distributionProgress[platform.id] || 0;
              const isActive = activeDistributions.includes(platform.id);
              
              return (
                <Card key={platform.id} className="glass-card border-white/10 hover:border-[#00ff88]/30 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Icon size={24} className="text-[#00ff88]" />
                        <CardTitle className="text-sm">{platform.name}</CardTitle>
                      </div>
                      <Badge 
                        className={
                          platform.status === 'live' ? 'bg-green-500/20 text-green-400' :
                          platform.status === 'processing' ? 'bg-blue-500/20 text-blue-400' :
                          'bg-gray-500/20 text-gray-400'
                        }
                      >
                        {platform.status}
                      </Badge>
                    </div>
                    <CardDescription className="text-xs">
                      {platform.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <div className="text-xs text-gray-400 mb-1">Requirements:</div>
                      <div className="text-xs">
                        {platform.requirements.slice(0, 2).map((req, idx) => (
                          <Badge key={idx} variant="outline" className="mr-1 mb-1 text-xs">
                            {req}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div className="text-xs">
                      <span className="text-[#00ff88]">Revenue:</span> {platform.revenue}
                    </div>

                    {isActive && progress < 100 && (
                      <div>
                        <div className="text-xs text-gray-400 mb-1">Distributing... {progress}%</div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-[#00ff88] h-2 rounded-full transition-all duration-500"
                            style={{ width: `${progress}%` }}
                          ></div>
                        </div>
                      </div>
                    )}

                    {progress === 100 ? (
                      <Badge className="w-full justify-center bg-green-500/20 text-green-400">
                        ✓ Live on {platform.name}
                      </Badge>
                    ) : (
                      <Button 
                        size="sm" 
                        className="w-full bg-gradient-to-r from-[#00ff88] to-[#0099ff] hover:from-[#00cc6a] hover:to-[#0077cc]"
                        onClick={() => handleDistribute(platform.id, 'movie')}
                        disabled={isActive && progress < 100}
                      >
                        <Upload size={14} className="mr-1" />
                        Distribute Now
                      </Button>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="marketing" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="glass-card border-[#ffd700]/20">
              <CardHeader>
                <CardTitle className="text-[#ffd700] flex items-center gap-2">
                  <TrendingUp size={20} />
                  Automated Marketing
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span>Social Media Campaigns</span>
                    <Badge className="bg-green-500/20 text-green-400">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Influencer Outreach</span>
                    <Badge className="bg-blue-500/20 text-blue-400">Scheduled</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Press Releases</span>
                    <Badge className="bg-yellow-500/20 text-yellow-400">Draft</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Email Marketing</span>
                    <Badge className="bg-green-500/20 text-green-400">Active</Badge>
                  </div>
                </div>
                
                <Button 
                  className="w-full bg-gradient-to-r from-[#ffd700] to-[#ff8c00] hover:from-[#e6c200] hover:to-[#e67300] text-black"
                  onClick={handleMarketingCampaign}
                >
                  <Zap size={16} className="mr-2" />
                  Launch Marketing Campaign
                </Button>
              </CardContent>
            </Card>

            <Card className="glass-card border-[#ff0080]/20">
              <CardHeader>
                <CardTitle className="text-[#ff0080] flex items-center gap-2">
                  <DollarSign size={20} />
                  Monetization Setup
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span>Ad Revenue Streams</span>
                    <Badge className="bg-green-500/20 text-green-400">Enabled</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Subscription Models</span>
                    <Badge className="bg-blue-500/20 text-blue-400">Setup</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Merchandise Integration</span>
                    <Badge className="bg-yellow-500/20 text-yellow-400">Pending</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span>Licensing Opportunities</span>
                    <Badge className="bg-green-500/20 text-green-400">Active</Badge>
                  </div>
                </div>
                
                <Button 
                  className="w-full bg-gradient-to-r from-[#ff0080] to-[#8000ff] hover:from-[#cc0066] hover:to-[#6600cc]"
                  onClick={handleMonetizationSetup}
                >
                  <DollarSign size={16} className="mr-2" />
                  Setup Monetization
                </Button>
              </CardContent>
            </Card>
          </div>

          <Card className="glass-card border-[#00ffff]/20">
            <CardHeader>
              <CardTitle className="text-[#00ffff] flex items-center gap-2">
                <Users size={20} />
                Audience Targeting
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-[#00ffff] mb-2 block">Target Demographics</label>
                  <Select>
                    <SelectTrigger className="glass-input">
                      <SelectValue placeholder="Select age group" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="18-24">18-24 years</SelectItem>
                      <SelectItem value="25-34">25-34 years</SelectItem>
                      <SelectItem value="35-44">35-44 years</SelectItem>
                      <SelectItem value="45-54">45-54 years</SelectItem>
                      <SelectItem value="all">All ages</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium text-[#00ffff] mb-2 block">Geographic Regions</label>
                  <Select>
                    <SelectTrigger className="glass-input">
                      <SelectValue placeholder="Select regions" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="global">Global</SelectItem>
                      <SelectItem value="north-america">North America</SelectItem>
                      <SelectItem value="europe">Europe</SelectItem>
                      <SelectItem value="asia">Asia Pacific</SelectItem>
                      <SelectItem value="latin-america">Latin America</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium text-[#00ffff] mb-2 block">Marketing Message</label>
                <Textarea 
                  className="glass-input"
                  placeholder="Enter your marketing message and key selling points..."
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="glass-card">
              <CardContent className="p-4 text-center">
                <BarChart3 className="mx-auto mb-2 text-[#00ff88]" size={24} />
                <div className="text-2xl font-bold text-[#00ff88]">$12,450</div>
                <div className="text-sm text-gray-400">This Month</div>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="p-4 text-center">
                <TrendingUp className="mx-auto mb-2 text-[#0099ff]" size={24} />
                <div className="text-2xl font-bold text-[#0099ff]">+23%</div>
                <div className="text-sm text-gray-400">Growth Rate</div>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="p-4 text-center">
                <Users className="mx-auto mb-2 text-[#ff0080]" size={24} />
                <div className="text-2xl font-bold text-[#ff0080]">847K</div>
                <div className="text-sm text-gray-400">Followers</div>
              </CardContent>
            </Card>
            <Card className="glass-card">
              <CardContent className="p-4 text-center">
                <Globe className="mx-auto mb-2 text-[#ffaa00]" size={24} />
                <div className="text-2xl font-bold text-[#ffaa00]">94</div>
                <div className="text-sm text-gray-400">Countries</div>
              </CardContent>
            </Card>
          </div>

          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-[#00ff88]">Revenue by Platform</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {platforms.slice(0, 4).map((platform, index) => {
                  const revenues = ['$15,420', '$8,930', '$5,670', '$3,210'];
                  const percentages = [45, 30, 18, 12];
                  
                  return (
                    <div key={platform.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <platform.icon size={20} className="text-[#00ff88]" />
                        <span>{platform.name}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="w-32 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-[#00ff88] h-2 rounded-full"
                            style={{ width: `${percentages[index]}%` }}
                          ></div>
                        </div>
                        <span className="text-[#00ff88] font-medium w-20 text-right">
                          {revenues[index]}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="automation" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="glass-card border-[#32cd32]/20">
              <CardHeader>
                <CardTitle className="text-[#32cd32] flex items-center gap-2">
                  <Settings size={20} />
                  Automated Distribution
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Auto-upload to YouTube</span>
                    <Badge className="bg-green-500/20 text-green-400">Enabled</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Spotify distribution</span>
                    <Badge className="bg-green-500/20 text-green-400">Enabled</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Social media posting</span>
                    <Badge className="bg-blue-500/20 text-blue-400">Scheduled</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Email notifications</span>
                    <Badge className="bg-green-500/20 text-green-400">Active</Badge>
                  </div>
                </div>
                
                <Button className="w-full bg-gradient-to-r from-[#32cd32] to-[#228b22] hover:from-[#2eb82e] hover:to-[#1e6b1e]">
                  <Zap size={16} className="mr-2" />
                  Configure Automation
                </Button>
              </CardContent>
            </Card>

            <Card className="glass-card border-[#ff6b6b]/20">
              <CardHeader>
                <CardTitle className="text-[#ff6b6b] flex items-center gap-2">
                  <Calendar size={20} />
                  Scheduled Releases
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="p-3 bg-white/5 rounded-lg">
                    <div className="text-sm font-medium">AI Revolution Movie</div>
                    <div className="text-xs text-gray-400">Releases in 2 days</div>
                  </div>
                  <div className="p-3 bg-white/5 rounded-lg">
                    <div className="text-sm font-medium">Digital Dreams Album</div>
                    <div className="text-xs text-gray-400">Releases next week</div>
                  </div>
                  <div className="p-3 bg-white/5 rounded-lg">
                    <div className="text-sm font-medium">Animation Series EP1</div>
                    <div className="text-xs text-gray-400">In review</div>
                  </div>
                </div>
                
                <Button className="w-full bg-gradient-to-r from-[#ff6b6b] to-[#ff5252] hover:from-[#ff5252] hover:to-[#ff4444]">
                  <Calendar size={16} className="mr-2" />
                  Schedule New Release
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
