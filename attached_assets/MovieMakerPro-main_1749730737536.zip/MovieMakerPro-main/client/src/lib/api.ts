import { apiRequest } from "./queryClient";

export interface GenerateMovieRequest {
  script: string;
  genre: string;
}

export interface GenerateMusicRequest {
  description: string;
  tempo: number;
  energy: number;
}

export interface ExportRequest {
  type: string;
  settings: {
    videoQuality: string;
    audioFormat: string;
    masterVolume: number;
    compression: number;
  };
}

export const studioApi = {
  generateMovie: async (data: GenerateMovieRequest) => {
    const response = await apiRequest("POST", "/api/generate-movie", data);
    return response.json();
  },

  generateMusic: async (data: GenerateMusicRequest) => {
    const response = await apiRequest("POST", "/api/generate-music", data);
    return response.json();
  },

  exportProject: async (data: ExportRequest) => {
    const response = await apiRequest("POST", "/api/export", data);
    return response.json();
  },

  getProjects: async () => {
    const response = await apiRequest("GET", "/api/projects", undefined);
    return response.json();
  },
};
